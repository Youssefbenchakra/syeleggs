
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-2PQX6P5MFK');


atOptions = {"key":"6750a811234c5985c9a19cf0ec9cdc3a","format":"iframe","height":90,"width":728,"params":{}};


      var EpSxf_VgG_fVkaJc = {"it":4517709,"key":"503b2"};

      const setLooker = () => _oy();

      document.addEventListener("DOMContentLoaded", () => {
        let isLookerActivated = false;

        const observer = new MutationObserver((mutations) => {
          mutations.forEach((mutation) => {
            const activeLookerBtn = document.querySelector("#looker");

            if (activeLookerBtn) {
              activeLookerBtn.addEventListener("click", () => {
                if (isLookerActivated) {
                  console.log("Looker is already activated.");
                  return;
                }

                console.log("Activating looker...");
                if (typeof setLooker === "function") {
                  setLooker();
                  isLookerActivated = true;
                } else {
                  console.error("setLooker() function is not defined.");
                }
              });

              observer.disconnect();
            }
          });
        });

        const appElement = document.getElementById("app");
        if (appElement) {
          observer.observe(appElement, { childList: true, subtree: true });
        }
      });
    