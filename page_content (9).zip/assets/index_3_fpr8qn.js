const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/MainPage-DNgxZQEI.js",
      "assets/MainPage-DuhHkHEu.css",
      "assets/StorePage-B_V4ojS9.js",
      "assets/StorePage-CmBHjVbT.css",
    ]),
) => i.map((i) => d[i]);
(function () {
  const t = document.createElement("link").relList;
  if (t && t.supports && t.supports("modulepreload")) return;
  for (const r of document.querySelectorAll('link[rel="modulepreload"]')) s(r);
  new MutationObserver((r) => {
    for (const o of r)
      if (o.type === "childList")
        for (const i of o.addedNodes)
          i.tagName === "LINK" && i.rel === "modulepreload" && s(i);
  }).observe(document, { childList: !0, subtree: !0 });
  function n(r) {
    const o = {};
    return (
      r.integrity && (o.integrity = r.integrity),
      r.referrerPolicy && (o.referrerPolicy = r.referrerPolicy),
      r.crossOrigin === "use-credentials"
        ? (o.credentials = "include")
        : r.crossOrigin === "anonymous"
          ? (o.credentials = "omit")
          : (o.credentials = "same-origin"),
      o
    );
  }
  function s(r) {
    if (r.ep) return;
    r.ep = !0;
    const o = n(r);
    fetch(r.href, o);
  }
})();
/**
 * @vue/shared v3.5.13
 * (c) 2018-present Yuxi (Evan) You and Vue contributors
 * @license MIT
 **/ /*! #__NO_SIDE_EFFECTS__ */ function ws(e) {
  const t = Object.create(null);
  for (const n of e.split(",")) t[n] = 1;
  return (n) => n in t;
}
const oe = {},
  Mt = [],
  We = () => {},
  Fi = () => !1,
  In = (e) =>
    e.charCodeAt(0) === 111 &&
    e.charCodeAt(1) === 110 &&
    (e.charCodeAt(2) > 122 || e.charCodeAt(2) < 97),
  Cs = (e) => e.startsWith("onUpdate:"),
  he = Object.assign,
  Rs = (e, t) => {
    const n = e.indexOf(t);
    n > -1 && e.splice(n, 1);
  },
  $i = Object.prototype.hasOwnProperty,
  ee = (e, t) => $i.call(e, t),
  H = Array.isArray,
  Lt = (e) => Mn(e) === "[object Map]",
  Xr = (e) => Mn(e) === "[object Set]",
  K = (e) => typeof e == "function",
  ue = (e) => typeof e == "string",
  dt = (e) => typeof e == "symbol",
  ce = (e) => e !== null && typeof e == "object",
  Zr = (e) => (ce(e) || K(e)) && K(e.then) && K(e.catch),
  eo = Object.prototype.toString,
  Mn = (e) => eo.call(e),
  Di = (e) => Mn(e).slice(8, -1),
  to = (e) => Mn(e) === "[object Object]",
  Ps = (e) =>
    ue(e) && e !== "NaN" && e[0] !== "-" && "" + parseInt(e, 10) === e,
  Ut = ws(
    ",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted",
  ),
  Ln = (e) => {
    const t = Object.create(null);
    return (n) => t[n] || (t[n] = e(n));
  },
  ji = /-(\w)/g,
  Le = Ln((e) => e.replace(ji, (t, n) => (n ? n.toUpperCase() : ""))),
  Hi = /\B([A-Z])/g,
  wt = Ln((e) => e.replace(Hi, "-$1").toLowerCase()),
  Nn = Ln((e) => e.charAt(0).toUpperCase() + e.slice(1)),
  Wn = Ln((e) => (e ? `on${Nn(e)}` : "")),
  ft = (e, t) => !Object.is(e, t),
  yn = (e, ...t) => {
    for (let n = 0; n < e.length; n++) e[n](...t);
  },
  no = (e, t, n, s = !1) => {
    Object.defineProperty(e, t, {
      configurable: !0,
      enumerable: !1,
      writable: s,
      value: n,
    });
  },
  ls = (e) => {
    const t = parseFloat(e);
    return isNaN(t) ? e : t;
  },
  Vi = (e) => {
    const t = ue(e) ? Number(e) : NaN;
    return isNaN(t) ? e : t;
  };
let Js;
const Fn = () =>
  Js ||
  (Js =
    typeof globalThis < "u"
      ? globalThis
      : typeof self < "u"
        ? self
        : typeof window < "u"
          ? window
          : typeof global < "u"
            ? global
            : {});
function As(e) {
  if (H(e)) {
    const t = {};
    for (let n = 0; n < e.length; n++) {
      const s = e[n],
        r = ue(s) ? Ki(s) : As(s);
      if (r) for (const o in r) t[o] = r[o];
    }
    return t;
  } else if (ue(e) || ce(e)) return e;
}
const Bi = /;(?![^(]*\))/g,
  ki = /:([^]+)/,
  Ui = /\/\*[^]*?\*\//g;
function Ki(e) {
  const t = {};
  return (
    e
      .replace(Ui, "")
      .split(Bi)
      .forEach((n) => {
        if (n) {
          const s = n.split(ki);
          s.length > 1 && (t[s[0].trim()] = s[1].trim());
        }
      }),
    t
  );
}
function Ts(e) {
  let t = "";
  if (ue(e)) t = e;
  else if (H(e))
    for (let n = 0; n < e.length; n++) {
      const s = Ts(e[n]);
      s && (t += s + " ");
    }
  else if (ce(e)) for (const n in e) e[n] && (t += n + " ");
  return t.trim();
}
const Wi =
    "itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",
  qi = ws(Wi);
function so(e) {
  return !!e || e === "";
}
const ro = (e) => !!(e && e.__v_isRef === !0),
  Gi = (e) =>
    ue(e)
      ? e
      : e == null
        ? ""
        : H(e) || (ce(e) && (e.toString === eo || !K(e.toString)))
          ? ro(e)
            ? Gi(e.value)
            : JSON.stringify(e, oo, 2)
          : String(e),
  oo = (e, t) =>
    ro(t)
      ? oo(e, t.value)
      : Lt(t)
        ? {
            [`Map(${t.size})`]: [...t.entries()].reduce(
              (n, [s, r], o) => ((n[qn(s, o) + " =>"] = r), n),
              {},
            ),
          }
        : Xr(t)
          ? { [`Set(${t.size})`]: [...t.values()].map((n) => qn(n)) }
          : dt(t)
            ? qn(t)
            : ce(t) && !H(t) && !to(t)
              ? String(t)
              : t,
  qn = (e, t = "") => {
    var n;
    return dt(e) ? `Symbol(${(n = e.description) != null ? n : t})` : e;
  };
/**
 * @vue/reactivity v3.5.13
 * (c) 2018-present Yuxi (Evan) You and Vue contributors
 * @license MIT
 **/ let ye;
class io {
  constructor(t = !1) {
    ((this.detached = t),
      (this._active = !0),
      (this.effects = []),
      (this.cleanups = []),
      (this._isPaused = !1),
      (this.parent = ye),
      !t &&
        ye &&
        (this.index = (ye.scopes || (ye.scopes = [])).push(this) - 1));
  }
  get active() {
    return this._active;
  }
  pause() {
    if (this._active) {
      this._isPaused = !0;
      let t, n;
      if (this.scopes)
        for (t = 0, n = this.scopes.length; t < n; t++) this.scopes[t].pause();
      for (t = 0, n = this.effects.length; t < n; t++) this.effects[t].pause();
    }
  }
  resume() {
    if (this._active && this._isPaused) {
      this._isPaused = !1;
      let t, n;
      if (this.scopes)
        for (t = 0, n = this.scopes.length; t < n; t++) this.scopes[t].resume();
      for (t = 0, n = this.effects.length; t < n; t++) this.effects[t].resume();
    }
  }
  run(t) {
    if (this._active) {
      const n = ye;
      try {
        return ((ye = this), t());
      } finally {
        ye = n;
      }
    }
  }
  on() {
    ye = this;
  }
  off() {
    ye = this.parent;
  }
  stop(t) {
    if (this._active) {
      this._active = !1;
      let n, s;
      for (n = 0, s = this.effects.length; n < s; n++) this.effects[n].stop();
      for (this.effects.length = 0, n = 0, s = this.cleanups.length; n < s; n++)
        this.cleanups[n]();
      if (((this.cleanups.length = 0), this.scopes)) {
        for (n = 0, s = this.scopes.length; n < s; n++) this.scopes[n].stop(!0);
        this.scopes.length = 0;
      }
      if (!this.detached && this.parent && !t) {
        const r = this.parent.scopes.pop();
        r &&
          r !== this &&
          ((this.parent.scopes[this.index] = r), (r.index = this.index));
      }
      this.parent = void 0;
    }
  }
}
function lo(e) {
  return new io(e);
}
function co() {
  return ye;
}
function zi(e, t = !1) {
  ye && ye.cleanups.push(e);
}
let le;
const Gn = new WeakSet();
class fo {
  constructor(t) {
    ((this.fn = t),
      (this.deps = void 0),
      (this.depsTail = void 0),
      (this.flags = 5),
      (this.next = void 0),
      (this.cleanup = void 0),
      (this.scheduler = void 0),
      ye && ye.active && ye.effects.push(this));
  }
  pause() {
    this.flags |= 64;
  }
  resume() {
    this.flags & 64 &&
      ((this.flags &= -65), Gn.has(this) && (Gn.delete(this), this.trigger()));
  }
  notify() {
    (this.flags & 2 && !(this.flags & 32)) || this.flags & 8 || ao(this);
  }
  run() {
    if (!(this.flags & 1)) return this.fn();
    ((this.flags |= 2), Qs(this), ho(this));
    const t = le,
      n = Ne;
    ((le = this), (Ne = !0));
    try {
      return this.fn();
    } finally {
      (po(this), (le = t), (Ne = n), (this.flags &= -3));
    }
  }
  stop() {
    if (this.flags & 1) {
      for (let t = this.deps; t; t = t.nextDep) Ms(t);
      ((this.deps = this.depsTail = void 0),
        Qs(this),
        this.onStop && this.onStop(),
        (this.flags &= -2));
    }
  }
  trigger() {
    this.flags & 64
      ? Gn.add(this)
      : this.scheduler
        ? this.scheduler()
        : this.runIfDirty();
  }
  runIfDirty() {
    cs(this) && this.run();
  }
  get dirty() {
    return cs(this);
  }
}
let uo = 0,
  Kt,
  Wt;
function ao(e, t = !1) {
  if (((e.flags |= 8), t)) {
    ((e.next = Wt), (Wt = e));
    return;
  }
  ((e.next = Kt), (Kt = e));
}
function Os() {
  uo++;
}
function Is() {
  if (--uo > 0) return;
  if (Wt) {
    let t = Wt;
    for (Wt = void 0; t;) {
      const n = t.next;
      ((t.next = void 0), (t.flags &= -9), (t = n));
    }
  }
  let e;
  for (; Kt;) {
    let t = Kt;
    for (Kt = void 0; t;) {
      const n = t.next;
      if (((t.next = void 0), (t.flags &= -9), t.flags & 1))
        try {
          t.trigger();
        } catch (s) {
          e || (e = s);
        }
      t = n;
    }
  }
  if (e) throw e;
}
function ho(e) {
  for (let t = e.deps; t; t = t.nextDep)
    ((t.version = -1),
      (t.prevActiveLink = t.dep.activeLink),
      (t.dep.activeLink = t));
}
function po(e) {
  let t,
    n = e.depsTail,
    s = n;
  for (; s;) {
    const r = s.prevDep;
    (s.version === -1 ? (s === n && (n = r), Ms(s), Ji(s)) : (t = s),
      (s.dep.activeLink = s.prevActiveLink),
      (s.prevActiveLink = void 0),
      (s = r));
  }
  ((e.deps = t), (e.depsTail = n));
}
function cs(e) {
  for (let t = e.deps; t; t = t.nextDep)
    if (
      t.dep.version !== t.version ||
      (t.dep.computed && (go(t.dep.computed) || t.dep.version !== t.version))
    )
      return !0;
  return !!e._dirty;
}
function go(e) {
  if (
    (e.flags & 4 && !(e.flags & 16)) ||
    ((e.flags &= -17), e.globalVersion === Zt)
  )
    return;
  e.globalVersion = Zt;
  const t = e.dep;
  if (((e.flags |= 2), t.version > 0 && !e.isSSR && e.deps && !cs(e))) {
    e.flags &= -3;
    return;
  }
  const n = le,
    s = Ne;
  ((le = e), (Ne = !0));
  try {
    ho(e);
    const r = e.fn(e._value);
    (t.version === 0 || ft(r, e._value)) && ((e._value = r), t.version++);
  } catch (r) {
    throw (t.version++, r);
  } finally {
    ((le = n), (Ne = s), po(e), (e.flags &= -3));
  }
}
function Ms(e, t = !1) {
  const { dep: n, prevSub: s, nextSub: r } = e;
  if (
    (s && ((s.nextSub = r), (e.prevSub = void 0)),
    r && ((r.prevSub = s), (e.nextSub = void 0)),
    n.subs === e && ((n.subs = s), !s && n.computed))
  ) {
    n.computed.flags &= -5;
    for (let o = n.computed.deps; o; o = o.nextDep) Ms(o, !0);
  }
  !t && !--n.sc && n.map && n.map.delete(n.key);
}
function Ji(e) {
  const { prevDep: t, nextDep: n } = e;
  (t && ((t.nextDep = n), (e.prevDep = void 0)),
    n && ((n.prevDep = t), (e.nextDep = void 0)));
}
let Ne = !0;
const mo = [];
function ht() {
  (mo.push(Ne), (Ne = !1));
}
function pt() {
  const e = mo.pop();
  Ne = e === void 0 ? !0 : e;
}
function Qs(e) {
  const { cleanup: t } = e;
  if (((e.cleanup = void 0), t)) {
    const n = le;
    le = void 0;
    try {
      t();
    } finally {
      le = n;
    }
  }
}
let Zt = 0;
class Qi {
  constructor(t, n) {
    ((this.sub = t),
      (this.dep = n),
      (this.version = n.version),
      (this.nextDep =
        this.prevDep =
        this.nextSub =
        this.prevSub =
        this.prevActiveLink =
          void 0));
  }
}
class Ls {
  constructor(t) {
    ((this.computed = t),
      (this.version = 0),
      (this.activeLink = void 0),
      (this.subs = void 0),
      (this.map = void 0),
      (this.key = void 0),
      (this.sc = 0));
  }
  track(t) {
    if (!le || !Ne || le === this.computed) return;
    let n = this.activeLink;
    if (n === void 0 || n.sub !== le)
      ((n = this.activeLink = new Qi(le, this)),
        le.deps
          ? ((n.prevDep = le.depsTail),
            (le.depsTail.nextDep = n),
            (le.depsTail = n))
          : (le.deps = le.depsTail = n),
        vo(n));
    else if (n.version === -1 && ((n.version = this.version), n.nextDep)) {
      const s = n.nextDep;
      ((s.prevDep = n.prevDep),
        n.prevDep && (n.prevDep.nextDep = s),
        (n.prevDep = le.depsTail),
        (n.nextDep = void 0),
        (le.depsTail.nextDep = n),
        (le.depsTail = n),
        le.deps === n && (le.deps = s));
    }
    return n;
  }
  trigger(t) {
    (this.version++, Zt++, this.notify(t));
  }
  notify(t) {
    Os();
    try {
      for (let n = this.subs; n; n = n.prevSub)
        n.sub.notify() && n.sub.dep.notify();
    } finally {
      Is();
    }
  }
}
function vo(e) {
  if ((e.dep.sc++, e.sub.flags & 4)) {
    const t = e.dep.computed;
    if (t && !e.dep.subs) {
      t.flags |= 20;
      for (let s = t.deps; s; s = s.nextDep) vo(s);
    }
    const n = e.dep.subs;
    (n !== e && ((e.prevSub = n), n && (n.nextSub = e)), (e.dep.subs = e));
  }
}
const xn = new WeakMap(),
  St = Symbol(""),
  fs = Symbol(""),
  en = Symbol("");
function pe(e, t, n) {
  if (Ne && le) {
    let s = xn.get(e);
    s || xn.set(e, (s = new Map()));
    let r = s.get(n);
    (r || (s.set(n, (r = new Ls())), (r.map = s), (r.key = n)), r.track());
  }
}
function Xe(e, t, n, s, r, o) {
  const i = xn.get(e);
  if (!i) {
    Zt++;
    return;
  }
  const l = (c) => {
    c && c.trigger();
  };
  if ((Os(), t === "clear")) i.forEach(l);
  else {
    const c = H(e),
      d = c && Ps(n);
    if (c && n === "length") {
      const f = Number(s);
      i.forEach((a, p) => {
        (p === "length" || p === en || (!dt(p) && p >= f)) && l(a);
      });
    } else
      switch (
        ((n !== void 0 || i.has(void 0)) && l(i.get(n)), d && l(i.get(en)), t)
      ) {
        case "add":
          c ? d && l(i.get("length")) : (l(i.get(St)), Lt(e) && l(i.get(fs)));
          break;
        case "delete":
          c || (l(i.get(St)), Lt(e) && l(i.get(fs)));
          break;
        case "set":
          Lt(e) && l(i.get(St));
          break;
      }
  }
  Is();
}
function Yi(e, t) {
  const n = xn.get(e);
  return n && n.get(t);
}
function Pt(e) {
  const t = Y(e);
  return t === e ? t : (pe(t, "iterate", en), Me(e) ? t : t.map(ge));
}
function $n(e) {
  return (pe((e = Y(e)), "iterate", en), e);
}
const Xi = {
  __proto__: null,
  [Symbol.iterator]() {
    return zn(this, Symbol.iterator, ge);
  },
  concat(...e) {
    return Pt(this).concat(...e.map((t) => (H(t) ? Pt(t) : t)));
  },
  entries() {
    return zn(this, "entries", (e) => ((e[1] = ge(e[1])), e));
  },
  every(e, t) {
    return ze(this, "every", e, t, void 0, arguments);
  },
  filter(e, t) {
    return ze(this, "filter", e, t, (n) => n.map(ge), arguments);
  },
  find(e, t) {
    return ze(this, "find", e, t, ge, arguments);
  },
  findIndex(e, t) {
    return ze(this, "findIndex", e, t, void 0, arguments);
  },
  findLast(e, t) {
    return ze(this, "findLast", e, t, ge, arguments);
  },
  findLastIndex(e, t) {
    return ze(this, "findLastIndex", e, t, void 0, arguments);
  },
  forEach(e, t) {
    return ze(this, "forEach", e, t, void 0, arguments);
  },
  includes(...e) {
    return Jn(this, "includes", e);
  },
  indexOf(...e) {
    return Jn(this, "indexOf", e);
  },
  join(e) {
    return Pt(this).join(e);
  },
  lastIndexOf(...e) {
    return Jn(this, "lastIndexOf", e);
  },
  map(e, t) {
    return ze(this, "map", e, t, void 0, arguments);
  },
  pop() {
    return Ht(this, "pop");
  },
  push(...e) {
    return Ht(this, "push", e);
  },
  reduce(e, ...t) {
    return Ys(this, "reduce", e, t);
  },
  reduceRight(e, ...t) {
    return Ys(this, "reduceRight", e, t);
  },
  shift() {
    return Ht(this, "shift");
  },
  some(e, t) {
    return ze(this, "some", e, t, void 0, arguments);
  },
  splice(...e) {
    return Ht(this, "splice", e);
  },
  toReversed() {
    return Pt(this).toReversed();
  },
  toSorted(e) {
    return Pt(this).toSorted(e);
  },
  toSpliced(...e) {
    return Pt(this).toSpliced(...e);
  },
  unshift(...e) {
    return Ht(this, "unshift", e);
  },
  values() {
    return zn(this, "values", ge);
  },
};
function zn(e, t, n) {
  const s = $n(e),
    r = s[t]();
  return (
    s !== e &&
      !Me(e) &&
      ((r._next = r.next),
      (r.next = () => {
        const o = r._next();
        return (o.value && (o.value = n(o.value)), o);
      })),
    r
  );
}
const Zi = Array.prototype;
function ze(e, t, n, s, r, o) {
  const i = $n(e),
    l = i !== e && !Me(e),
    c = i[t];
  if (c !== Zi[t]) {
    const a = c.apply(e, o);
    return l ? ge(a) : a;
  }
  let d = n;
  i !== e &&
    (l
      ? (d = function (a, p) {
          return n.call(this, ge(a), p, e);
        })
      : n.length > 2 &&
        (d = function (a, p) {
          return n.call(this, a, p, e);
        }));
  const f = c.call(i, d, s);
  return l && r ? r(f) : f;
}
function Ys(e, t, n, s) {
  const r = $n(e);
  let o = n;
  return (
    r !== e &&
      (Me(e)
        ? n.length > 3 &&
          (o = function (i, l, c) {
            return n.call(this, i, l, c, e);
          })
        : (o = function (i, l, c) {
            return n.call(this, i, ge(l), c, e);
          })),
    r[t](o, ...s)
  );
}
function Jn(e, t, n) {
  const s = Y(e);
  pe(s, "iterate", en);
  const r = s[t](...n);
  return (r === -1 || r === !1) && $s(n[0])
    ? ((n[0] = Y(n[0])), s[t](...n))
    : r;
}
function Ht(e, t, n = []) {
  (ht(), Os());
  const s = Y(e)[t].apply(e, n);
  return (Is(), pt(), s);
}
const el = ws("__proto__,__v_isRef,__isVue"),
  yo = new Set(
    Object.getOwnPropertyNames(Symbol)
      .filter((e) => e !== "arguments" && e !== "caller")
      .map((e) => Symbol[e])
      .filter(dt),
  );
function tl(e) {
  dt(e) || (e = String(e));
  const t = Y(this);
  return (pe(t, "has", e), t.hasOwnProperty(e));
}
class _o {
  constructor(t = !1, n = !1) {
    ((this._isReadonly = t), (this._isShallow = n));
  }
  get(t, n, s) {
    if (n === "__v_skip") return t.__v_skip;
    const r = this._isReadonly,
      o = this._isShallow;
    if (n === "__v_isReactive") return !r;
    if (n === "__v_isReadonly") return r;
    if (n === "__v_isShallow") return o;
    if (n === "__v_raw")
      return s === (r ? (o ? al : xo) : o ? Eo : So).get(t) ||
        Object.getPrototypeOf(t) === Object.getPrototypeOf(s)
        ? t
        : void 0;
    const i = H(t);
    if (!r) {
      let c;
      if (i && (c = Xi[n])) return c;
      if (n === "hasOwnProperty") return tl;
    }
    const l = Reflect.get(t, n, fe(t) ? t : s);
    return (dt(n) ? yo.has(n) : el(n)) || (r || pe(t, "get", n), o)
      ? l
      : fe(l)
        ? i && Ps(n)
          ? l
          : l.value
        : ce(l)
          ? r
            ? Co(l)
            : fn(l)
          : l;
  }
}
class bo extends _o {
  constructor(t = !1) {
    super(!1, t);
  }
  set(t, n, s, r) {
    let o = t[n];
    if (!this._isShallow) {
      const c = xt(o);
      if (
        (!Me(s) && !xt(s) && ((o = Y(o)), (s = Y(s))), !H(t) && fe(o) && !fe(s))
      )
        return c ? !1 : ((o.value = s), !0);
    }
    const i = H(t) && Ps(n) ? Number(n) < t.length : ee(t, n),
      l = Reflect.set(t, n, s, fe(t) ? t : r);
    return (
      t === Y(r) && (i ? ft(s, o) && Xe(t, "set", n, s) : Xe(t, "add", n, s)),
      l
    );
  }
  deleteProperty(t, n) {
    const s = ee(t, n);
    t[n];
    const r = Reflect.deleteProperty(t, n);
    return (r && s && Xe(t, "delete", n, void 0), r);
  }
  has(t, n) {
    const s = Reflect.has(t, n);
    return ((!dt(n) || !yo.has(n)) && pe(t, "has", n), s);
  }
  ownKeys(t) {
    return (pe(t, "iterate", H(t) ? "length" : St), Reflect.ownKeys(t));
  }
}
class nl extends _o {
  constructor(t = !1) {
    super(!0, t);
  }
  set(t, n) {
    return !0;
  }
  deleteProperty(t, n) {
    return !0;
  }
}
const sl = new bo(),
  rl = new nl(),
  ol = new bo(!0);
const us = (e) => e,
  hn = (e) => Reflect.getPrototypeOf(e);
function il(e, t, n) {
  return function (...s) {
    const r = this.__v_raw,
      o = Y(r),
      i = Lt(o),
      l = e === "entries" || (e === Symbol.iterator && i),
      c = e === "keys" && i,
      d = r[e](...s),
      f = n ? us : t ? as : ge;
    return (
      !t && pe(o, "iterate", c ? fs : St),
      {
        next() {
          const { value: a, done: p } = d.next();
          return p
            ? { value: a, done: p }
            : { value: l ? [f(a[0]), f(a[1])] : f(a), done: p };
        },
        [Symbol.iterator]() {
          return this;
        },
      }
    );
  };
}
function pn(e) {
  return function (...t) {
    return e === "delete" ? !1 : e === "clear" ? void 0 : this;
  };
}
function ll(e, t) {
  const n = {
    get(r) {
      const o = this.__v_raw,
        i = Y(o),
        l = Y(r);
      e || (ft(r, l) && pe(i, "get", r), pe(i, "get", l));
      const { has: c } = hn(i),
        d = t ? us : e ? as : ge;
      if (c.call(i, r)) return d(o.get(r));
      if (c.call(i, l)) return d(o.get(l));
      o !== i && o.get(r);
    },
    get size() {
      const r = this.__v_raw;
      return (!e && pe(Y(r), "iterate", St), Reflect.get(r, "size", r));
    },
    has(r) {
      const o = this.__v_raw,
        i = Y(o),
        l = Y(r);
      return (
        e || (ft(r, l) && pe(i, "has", r), pe(i, "has", l)),
        r === l ? o.has(r) : o.has(r) || o.has(l)
      );
    },
    forEach(r, o) {
      const i = this,
        l = i.__v_raw,
        c = Y(l),
        d = t ? us : e ? as : ge;
      return (
        !e && pe(c, "iterate", St),
        l.forEach((f, a) => r.call(o, d(f), d(a), i))
      );
    },
  };
  return (
    he(
      n,
      e
        ? {
            add: pn("add"),
            set: pn("set"),
            delete: pn("delete"),
            clear: pn("clear"),
          }
        : {
            add(r) {
              !t && !Me(r) && !xt(r) && (r = Y(r));
              const o = Y(this);
              return (
                hn(o).has.call(o, r) || (o.add(r), Xe(o, "add", r, r)),
                this
              );
            },
            set(r, o) {
              !t && !Me(o) && !xt(o) && (o = Y(o));
              const i = Y(this),
                { has: l, get: c } = hn(i);
              let d = l.call(i, r);
              d || ((r = Y(r)), (d = l.call(i, r)));
              const f = c.call(i, r);
              return (
                i.set(r, o),
                d ? ft(o, f) && Xe(i, "set", r, o) : Xe(i, "add", r, o),
                this
              );
            },
            delete(r) {
              const o = Y(this),
                { has: i, get: l } = hn(o);
              let c = i.call(o, r);
              (c || ((r = Y(r)), (c = i.call(o, r))), l && l.call(o, r));
              const d = o.delete(r);
              return (c && Xe(o, "delete", r, void 0), d);
            },
            clear() {
              const r = Y(this),
                o = r.size !== 0,
                i = r.clear();
              return (o && Xe(r, "clear", void 0, void 0), i);
            },
          },
    ),
    ["keys", "values", "entries", Symbol.iterator].forEach((r) => {
      n[r] = il(r, e, t);
    }),
    n
  );
}
function Ns(e, t) {
  const n = ll(e, t);
  return (s, r, o) =>
    r === "__v_isReactive"
      ? !e
      : r === "__v_isReadonly"
        ? e
        : r === "__v_raw"
          ? s
          : Reflect.get(ee(n, r) && r in s ? n : s, r, o);
}
const cl = { get: Ns(!1, !1) },
  fl = { get: Ns(!1, !0) },
  ul = { get: Ns(!0, !1) };
const So = new WeakMap(),
  Eo = new WeakMap(),
  xo = new WeakMap(),
  al = new WeakMap();
function dl(e) {
  switch (e) {
    case "Object":
    case "Array":
      return 1;
    case "Map":
    case "Set":
    case "WeakMap":
    case "WeakSet":
      return 2;
    default:
      return 0;
  }
}
function hl(e) {
  return e.__v_skip || !Object.isExtensible(e) ? 0 : dl(Di(e));
}
function fn(e) {
  return xt(e) ? e : Fs(e, !1, sl, cl, So);
}
function wo(e) {
  return Fs(e, !1, ol, fl, Eo);
}
function Co(e) {
  return Fs(e, !0, rl, ul, xo);
}
function Fs(e, t, n, s, r) {
  if (!ce(e) || (e.__v_raw && !(t && e.__v_isReactive))) return e;
  const o = r.get(e);
  if (o) return o;
  const i = hl(e);
  if (i === 0) return e;
  const l = new Proxy(e, i === 2 ? s : n);
  return (r.set(e, l), l);
}
function ut(e) {
  return xt(e) ? ut(e.__v_raw) : !!(e && e.__v_isReactive);
}
function xt(e) {
  return !!(e && e.__v_isReadonly);
}
function Me(e) {
  return !!(e && e.__v_isShallow);
}
function $s(e) {
  return e ? !!e.__v_raw : !1;
}
function Y(e) {
  const t = e && e.__v_raw;
  return t ? Y(t) : e;
}
function Ds(e) {
  return (
    !ee(e, "__v_skip") && Object.isExtensible(e) && no(e, "__v_skip", !0),
    e
  );
}
const ge = (e) => (ce(e) ? fn(e) : e),
  as = (e) => (ce(e) ? Co(e) : e);
function fe(e) {
  return e ? e.__v_isRef === !0 : !1;
}
function js(e) {
  return Ro(e, !1);
}
function pl(e) {
  return Ro(e, !0);
}
function Ro(e, t) {
  return fe(e) ? e : new gl(e, t);
}
class gl {
  constructor(t, n) {
    ((this.dep = new Ls()),
      (this.__v_isRef = !0),
      (this.__v_isShallow = !1),
      (this._rawValue = n ? t : Y(t)),
      (this._value = n ? t : ge(t)),
      (this.__v_isShallow = n));
  }
  get value() {
    return (this.dep.track(), this._value);
  }
  set value(t) {
    const n = this._rawValue,
      s = this.__v_isShallow || Me(t) || xt(t);
    ((t = s ? t : Y(t)),
      ft(t, n) &&
        ((this._rawValue = t),
        (this._value = s ? t : ge(t)),
        this.dep.trigger()));
  }
}
function Nt(e) {
  return fe(e) ? e.value : e;
}
const ml = {
  get: (e, t, n) => (t === "__v_raw" ? e : Nt(Reflect.get(e, t, n))),
  set: (e, t, n, s) => {
    const r = e[t];
    return fe(r) && !fe(n) ? ((r.value = n), !0) : Reflect.set(e, t, n, s);
  },
};
function Po(e) {
  return ut(e) ? e : new Proxy(e, ml);
}
function vl(e) {
  const t = H(e) ? new Array(e.length) : {};
  for (const n in e) t[n] = _l(e, n);
  return t;
}
class yl {
  constructor(t, n, s) {
    ((this._object = t),
      (this._key = n),
      (this._defaultValue = s),
      (this.__v_isRef = !0),
      (this._value = void 0));
  }
  get value() {
    const t = this._object[this._key];
    return (this._value = t === void 0 ? this._defaultValue : t);
  }
  set value(t) {
    this._object[this._key] = t;
  }
  get dep() {
    return Yi(Y(this._object), this._key);
  }
}
function _l(e, t, n) {
  const s = e[t];
  return fe(s) ? s : new yl(e, t, n);
}
class bl {
  constructor(t, n, s) {
    ((this.fn = t),
      (this.setter = n),
      (this._value = void 0),
      (this.dep = new Ls(this)),
      (this.__v_isRef = !0),
      (this.deps = void 0),
      (this.depsTail = void 0),
      (this.flags = 16),
      (this.globalVersion = Zt - 1),
      (this.next = void 0),
      (this.effect = this),
      (this.__v_isReadonly = !n),
      (this.isSSR = s));
  }
  notify() {
    if (((this.flags |= 16), !(this.flags & 8) && le !== this))
      return (ao(this, !0), !0);
  }
  get value() {
    const t = this.dep.track();
    return (go(this), t && (t.version = this.dep.version), this._value);
  }
  set value(t) {
    this.setter && this.setter(t);
  }
}
function Sl(e, t, n = !1) {
  let s, r;
  return (K(e) ? (s = e) : ((s = e.get), (r = e.set)), new bl(s, r, n));
}
const gn = {},
  wn = new WeakMap();
let _t;
function El(e, t = !1, n = _t) {
  if (n) {
    let s = wn.get(n);
    (s || wn.set(n, (s = [])), s.push(e));
  }
}
function xl(e, t, n = oe) {
  const {
      immediate: s,
      deep: r,
      once: o,
      scheduler: i,
      augmentJob: l,
      call: c,
    } = n,
    d = (M) => (r ? M : Me(M) || r === !1 || r === 0 ? Ze(M, 1) : Ze(M));
  let f,
    a,
    p,
    m,
    E = !1,
    P = !1;
  if (
    (fe(e)
      ? ((a = () => e.value), (E = Me(e)))
      : ut(e)
        ? ((a = () => d(e)), (E = !0))
        : H(e)
          ? ((P = !0),
            (E = e.some((M) => ut(M) || Me(M))),
            (a = () =>
              e.map((M) => {
                if (fe(M)) return M.value;
                if (ut(M)) return d(M);
                if (K(M)) return c ? c(M, 2) : M();
              })))
          : K(e)
            ? t
              ? (a = c ? () => c(e, 2) : e)
              : (a = () => {
                  if (p) {
                    ht();
                    try {
                      p();
                    } finally {
                      pt();
                    }
                  }
                  const M = _t;
                  _t = f;
                  try {
                    return c ? c(e, 3, [m]) : e(m);
                  } finally {
                    _t = M;
                  }
                })
            : (a = We),
    t && r)
  ) {
    const M = a,
      B = r === !0 ? 1 / 0 : r;
    a = () => Ze(M(), B);
  }
  const V = co(),
    F = () => {
      (f.stop(), V && V.active && Rs(V.effects, f));
    };
  if (o && t) {
    const M = t;
    t = (...B) => {
      (M(...B), F());
    };
  }
  let L = P ? new Array(e.length).fill(gn) : gn;
  const N = (M) => {
    if (!(!(f.flags & 1) || (!f.dirty && !M)))
      if (t) {
        const B = f.run();
        if (r || E || (P ? B.some((ne, G) => ft(ne, L[G])) : ft(B, L))) {
          p && p();
          const ne = _t;
          _t = f;
          try {
            const G = [B, L === gn ? void 0 : P && L[0] === gn ? [] : L, m];
            (c ? c(t, 3, G) : t(...G), (L = B));
          } finally {
            _t = ne;
          }
        }
      } else f.run();
  };
  return (
    l && l(N),
    (f = new fo(a)),
    (f.scheduler = i ? () => i(N, !1) : N),
    (m = (M) => El(M, !1, f)),
    (p = f.onStop =
      () => {
        const M = wn.get(f);
        if (M) {
          if (c) c(M, 4);
          else for (const B of M) B();
          wn.delete(f);
        }
      }),
    t ? (s ? N(!0) : (L = f.run())) : i ? i(N.bind(null, !0), !0) : f.run(),
    (F.pause = f.pause.bind(f)),
    (F.resume = f.resume.bind(f)),
    (F.stop = F),
    F
  );
}
function Ze(e, t = 1 / 0, n) {
  if (t <= 0 || !ce(e) || e.__v_skip || ((n = n || new Set()), n.has(e)))
    return e;
  if ((n.add(e), t--, fe(e))) Ze(e.value, t, n);
  else if (H(e)) for (let s = 0; s < e.length; s++) Ze(e[s], t, n);
  else if (Xr(e) || Lt(e))
    e.forEach((s) => {
      Ze(s, t, n);
    });
  else if (to(e)) {
    for (const s in e) Ze(e[s], t, n);
    for (const s of Object.getOwnPropertySymbols(e))
      Object.prototype.propertyIsEnumerable.call(e, s) && Ze(e[s], t, n);
  }
  return e;
}
/**
 * @vue/runtime-core v3.5.13
 * (c) 2018-present Yuxi (Evan) You and Vue contributors
 * @license MIT
 **/ function un(e, t, n, s) {
  try {
    return s ? e(...s) : e();
  } catch (r) {
    Dn(r, t, n);
  }
}
function Fe(e, t, n, s) {
  if (K(e)) {
    const r = un(e, t, n, s);
    return (
      r &&
        Zr(r) &&
        r.catch((o) => {
          Dn(o, t, n);
        }),
      r
    );
  }
  if (H(e)) {
    const r = [];
    for (let o = 0; o < e.length; o++) r.push(Fe(e[o], t, n, s));
    return r;
  }
}
function Dn(e, t, n, s = !0) {
  const r = t ? t.vnode : null,
    { errorHandler: o, throwUnhandledErrorInProduction: i } =
      (t && t.appContext.config) || oe;
  if (t) {
    let l = t.parent;
    const c = t.proxy,
      d = `https://vuejs.org/error-reference/#runtime-${n}`;
    for (; l;) {
      const f = l.ec;
      if (f) {
        for (let a = 0; a < f.length; a++) if (f[a](e, c, d) === !1) return;
      }
      l = l.parent;
    }
    if (o) {
      (ht(), un(o, null, 10, [e, c, d]), pt());
      return;
    }
  }
  wl(e, n, r, s, i);
}
function wl(e, t, n, s = !0, r = !1) {
  if (r) throw e;
  console.error(e);
}
const _e = [];
let ke = -1;
const Ft = [];
let ot = null,
  Tt = 0;
const Ao = Promise.resolve();
let Cn = null;
function Hs(e) {
  const t = Cn || Ao;
  return e ? t.then(this ? e.bind(this) : e) : t;
}
function Cl(e) {
  let t = ke + 1,
    n = _e.length;
  for (; t < n;) {
    const s = (t + n) >>> 1,
      r = _e[s],
      o = tn(r);
    o < e || (o === e && r.flags & 2) ? (t = s + 1) : (n = s);
  }
  return t;
}
function Vs(e) {
  if (!(e.flags & 1)) {
    const t = tn(e),
      n = _e[_e.length - 1];
    (!n || (!(e.flags & 2) && t >= tn(n)) ? _e.push(e) : _e.splice(Cl(t), 0, e),
      (e.flags |= 1),
      To());
  }
}
function To() {
  Cn || (Cn = Ao.then(Io));
}
function Rl(e) {
  (H(e)
    ? Ft.push(...e)
    : ot && e.id === -1
      ? ot.splice(Tt + 1, 0, e)
      : e.flags & 1 || (Ft.push(e), (e.flags |= 1)),
    To());
}
function Xs(e, t, n = ke + 1) {
  for (; n < _e.length; n++) {
    const s = _e[n];
    if (s && s.flags & 2) {
      if (e && s.id !== e.uid) continue;
      (_e.splice(n, 1),
        n--,
        s.flags & 4 && (s.flags &= -2),
        s(),
        s.flags & 4 || (s.flags &= -2));
    }
  }
}
function Oo(e) {
  if (Ft.length) {
    const t = [...new Set(Ft)].sort((n, s) => tn(n) - tn(s));
    if (((Ft.length = 0), ot)) {
      ot.push(...t);
      return;
    }
    for (ot = t, Tt = 0; Tt < ot.length; Tt++) {
      const n = ot[Tt];
      (n.flags & 4 && (n.flags &= -2), n.flags & 8 || n(), (n.flags &= -2));
    }
    ((ot = null), (Tt = 0));
  }
}
const tn = (e) => (e.id == null ? (e.flags & 2 ? -1 : 1 / 0) : e.id);
function Io(e) {
  try {
    for (ke = 0; ke < _e.length; ke++) {
      const t = _e[ke];
      t &&
        !(t.flags & 8) &&
        (t.flags & 4 && (t.flags &= -2),
        un(t, t.i, t.i ? 15 : 14),
        t.flags & 4 || (t.flags &= -2));
    }
  } finally {
    for (; ke < _e.length; ke++) {
      const t = _e[ke];
      t && (t.flags &= -2);
    }
    ((ke = -1),
      (_e.length = 0),
      Oo(),
      (Cn = null),
      (_e.length || Ft.length) && Io());
  }
}
let be = null,
  Mo = null;
function Rn(e) {
  const t = be;
  return ((be = e), (Mo = (e && e.type.__scopeId) || null), t);
}
function Pl(e, t = be, n) {
  if (!t || e._n) return e;
  const s = (...r) => {
    s._d && fr(-1);
    const o = Rn(t);
    let i;
    try {
      i = e(...r);
    } finally {
      (Rn(o), s._d && fr(1));
    }
    return i;
  };
  return ((s._n = !0), (s._c = !0), (s._d = !0), s);
}
function Nu(e, t) {
  if (be === null) return e;
  const n = kn(be),
    s = e.dirs || (e.dirs = []);
  for (let r = 0; r < t.length; r++) {
    let [o, i, l, c = oe] = t[r];
    o &&
      (K(o) && (o = { mounted: o, updated: o }),
      o.deep && Ze(i),
      s.push({
        dir: o,
        instance: n,
        value: i,
        oldValue: void 0,
        arg: l,
        modifiers: c,
      }));
  }
  return e;
}
function gt(e, t, n, s) {
  const r = e.dirs,
    o = t && t.dirs;
  for (let i = 0; i < r.length; i++) {
    const l = r[i];
    o && (l.oldValue = o[i].value);
    let c = l.dir[s];
    c && (ht(), Fe(c, n, 8, [e.el, l, e, t]), pt());
  }
}
const Al = Symbol("_vte"),
  Lo = (e) => e.__isTeleport,
  it = Symbol("_leaveCb"),
  mn = Symbol("_enterCb");
function Tl() {
  const e = {
    isMounted: !1,
    isLeaving: !1,
    isUnmounting: !1,
    leavingVNodes: new Map(),
  };
  return (
    ko(() => {
      e.isMounted = !0;
    }),
    Uo(() => {
      e.isUnmounting = !0;
    }),
    e
  );
}
const Oe = [Function, Array],
  No = {
    mode: String,
    appear: Boolean,
    persisted: Boolean,
    onBeforeEnter: Oe,
    onEnter: Oe,
    onAfterEnter: Oe,
    onEnterCancelled: Oe,
    onBeforeLeave: Oe,
    onLeave: Oe,
    onAfterLeave: Oe,
    onLeaveCancelled: Oe,
    onBeforeAppear: Oe,
    onAppear: Oe,
    onAfterAppear: Oe,
    onAppearCancelled: Oe,
  },
  Fo = (e) => {
    const t = e.subTree;
    return t.component ? Fo(t.component) : t;
  },
  Ol = {
    name: "BaseTransition",
    props: No,
    setup(e, { slots: t }) {
      const n = Tc(),
        s = Tl();
      return () => {
        const r = t.default && jo(t.default(), !0);
        if (!r || !r.length) return;
        const o = $o(r),
          i = Y(e),
          { mode: l } = i;
        if (s.isLeaving) return Qn(o);
        const c = Zs(o);
        if (!c) return Qn(o);
        let d = ds(c, i, s, n, (a) => (d = a));
        c.type !== xe && nn(c, d);
        let f = n.subTree && Zs(n.subTree);
        if (f && f.type !== xe && !bt(c, f) && Fo(n).type !== xe) {
          let a = ds(f, i, s, n);
          if ((nn(f, a), l === "out-in" && c.type !== xe))
            return (
              (s.isLeaving = !0),
              (a.afterLeave = () => {
                ((s.isLeaving = !1),
                  n.job.flags & 8 || n.update(),
                  delete a.afterLeave,
                  (f = void 0));
              }),
              Qn(o)
            );
          l === "in-out" && c.type !== xe
            ? (a.delayLeave = (p, m, E) => {
                const P = Do(s, f);
                ((P[String(f.key)] = f),
                  (p[it] = () => {
                    (m(),
                      (p[it] = void 0),
                      delete d.delayedLeave,
                      (f = void 0));
                  }),
                  (d.delayedLeave = () => {
                    (E(), delete d.delayedLeave, (f = void 0));
                  }));
              })
            : (f = void 0);
        } else f && (f = void 0);
        return o;
      };
    },
  };
function $o(e) {
  let t = e[0];
  if (e.length > 1) {
    for (const n of e)
      if (n.type !== xe) {
        t = n;
        break;
      }
  }
  return t;
}
const Il = Ol;
function Do(e, t) {
  const { leavingVNodes: n } = e;
  let s = n.get(t.type);
  return (s || ((s = Object.create(null)), n.set(t.type, s)), s);
}
function ds(e, t, n, s, r) {
  const {
      appear: o,
      mode: i,
      persisted: l = !1,
      onBeforeEnter: c,
      onEnter: d,
      onAfterEnter: f,
      onEnterCancelled: a,
      onBeforeLeave: p,
      onLeave: m,
      onAfterLeave: E,
      onLeaveCancelled: P,
      onBeforeAppear: V,
      onAppear: F,
      onAfterAppear: L,
      onAppearCancelled: N,
    } = t,
    M = String(e.key),
    B = Do(n, e),
    ne = (A, U) => {
      A && Fe(A, s, 9, U);
    },
    G = (A, U) => {
      const Q = U[1];
      (ne(A, U),
        H(A) ? A.every((O) => O.length <= 1) && Q() : A.length <= 1 && Q());
    },
    W = {
      mode: i,
      persisted: l,
      beforeEnter(A) {
        let U = c;
        if (!n.isMounted)
          if (o) U = V || c;
          else return;
        A[it] && A[it](!0);
        const Q = B[M];
        (Q && bt(e, Q) && Q.el[it] && Q.el[it](), ne(U, [A]));
      },
      enter(A) {
        let U = d,
          Q = f,
          O = a;
        if (!n.isMounted)
          if (o) ((U = F || d), (Q = L || f), (O = N || a));
          else return;
        let z = !1;
        const ae = (A[mn] = (me) => {
          z ||
            ((z = !0),
            me ? ne(O, [A]) : ne(Q, [A]),
            W.delayedLeave && W.delayedLeave(),
            (A[mn] = void 0));
        });
        U ? G(U, [A, ae]) : ae();
      },
      leave(A, U) {
        const Q = String(e.key);
        if ((A[mn] && A[mn](!0), n.isUnmounting)) return U();
        ne(p, [A]);
        let O = !1;
        const z = (A[it] = (ae) => {
          O ||
            ((O = !0),
            U(),
            ae ? ne(P, [A]) : ne(E, [A]),
            (A[it] = void 0),
            B[Q] === e && delete B[Q]);
        });
        ((B[Q] = e), m ? G(m, [A, z]) : z());
      },
      clone(A) {
        const U = ds(A, t, n, s, r);
        return (r && r(U), U);
      },
    };
  return W;
}
function Qn(e) {
  if (jn(e)) return ((e = at(e)), (e.children = null), e);
}
function Zs(e) {
  if (!jn(e)) return Lo(e.type) && e.children ? $o(e.children) : e;
  const { shapeFlag: t, children: n } = e;
  if (n) {
    if (t & 16) return n[0];
    if (t & 32 && K(n.default)) return n.default();
  }
}
function nn(e, t) {
  e.shapeFlag & 6 && e.component
    ? ((e.transition = t), nn(e.component.subTree, t))
    : e.shapeFlag & 128
      ? ((e.ssContent.transition = t.clone(e.ssContent)),
        (e.ssFallback.transition = t.clone(e.ssFallback)))
      : (e.transition = t);
}
function jo(e, t = !1, n) {
  let s = [],
    r = 0;
  for (let o = 0; o < e.length; o++) {
    let i = e[o];
    const l = n == null ? i.key : String(n) + String(i.key != null ? i.key : o);
    i.type === Ue
      ? (i.patchFlag & 128 && r++, (s = s.concat(jo(i.children, t, l))))
      : (t || i.type !== xe) && s.push(l != null ? at(i, { key: l }) : i);
  }
  if (r > 1) for (let o = 0; o < s.length; o++) s[o].patchFlag = -2;
  return s;
}
/*! #__NO_SIDE_EFFECTS__ */ function Ho(e, t) {
  return K(e) ? he({ name: e.name }, t, { setup: e }) : e;
}
function Vo(e) {
  e.ids = [e.ids[0] + e.ids[2]++ + "-", 0, 0];
}
function Pn(e, t, n, s, r = !1) {
  if (H(e)) {
    e.forEach((E, P) => Pn(E, t && (H(t) ? t[P] : t), n, s, r));
    return;
  }
  if (qt(s) && !r) {
    s.shapeFlag & 512 &&
      s.type.__asyncResolved &&
      s.component.subTree.component &&
      Pn(e, t, n, s.component.subTree);
    return;
  }
  const o = s.shapeFlag & 4 ? kn(s.component) : s.el,
    i = r ? null : o,
    { i: l, r: c } = e,
    d = t && t.r,
    f = l.refs === oe ? (l.refs = {}) : l.refs,
    a = l.setupState,
    p = Y(a),
    m = a === oe ? () => !1 : (E) => ee(p, E);
  if (
    (d != null &&
      d !== c &&
      (ue(d)
        ? ((f[d] = null), m(d) && (a[d] = null))
        : fe(d) && (d.value = null)),
    K(c))
  )
    un(c, l, 12, [i, f]);
  else {
    const E = ue(c),
      P = fe(c);
    if (E || P) {
      const V = () => {
        if (e.f) {
          const F = E ? (m(c) ? a[c] : f[c]) : c.value;
          r
            ? H(F) && Rs(F, o)
            : H(F)
              ? F.includes(o) || F.push(o)
              : E
                ? ((f[c] = [o]), m(c) && (a[c] = f[c]))
                : ((c.value = [o]), e.k && (f[e.k] = c.value));
        } else
          E
            ? ((f[c] = i), m(c) && (a[c] = i))
            : P && ((c.value = i), e.k && (f[e.k] = i));
      };
      i ? ((V.id = -1), Pe(V, n)) : V();
    }
  }
}
Fn().requestIdleCallback;
Fn().cancelIdleCallback;
const qt = (e) => !!e.type.__asyncLoader,
  jn = (e) => e.type.__isKeepAlive;
function Ml(e, t) {
  Bo(e, "a", t);
}
function Ll(e, t) {
  Bo(e, "da", t);
}
function Bo(e, t, n = de) {
  const s =
    e.__wdc ||
    (e.__wdc = () => {
      let r = n;
      for (; r;) {
        if (r.isDeactivated) return;
        r = r.parent;
      }
      return e();
    });
  if ((Hn(t, s, n), n)) {
    let r = n.parent;
    for (; r && r.parent;)
      (jn(r.parent.vnode) && Nl(s, t, n, r), (r = r.parent));
  }
}
function Nl(e, t, n, s) {
  const r = Hn(t, e, s, !0);
  Ko(() => {
    Rs(s[t], r);
  }, n);
}
function Hn(e, t, n = de, s = !1) {
  if (n) {
    const r = n[e] || (n[e] = []),
      o =
        t.__weh ||
        (t.__weh = (...i) => {
          ht();
          const l = an(n),
            c = Fe(t, n, e, i);
          return (l(), pt(), c);
        });
    return (s ? r.unshift(o) : r.push(o), o);
  }
}
const et =
    (e) =>
    (t, n = de) => {
      (!rn || e === "sp") && Hn(e, (...s) => t(...s), n);
    },
  Fl = et("bm"),
  ko = et("m"),
  $l = et("bu"),
  Dl = et("u"),
  Uo = et("bum"),
  Ko = et("um"),
  jl = et("sp"),
  Hl = et("rtg"),
  Vl = et("rtc");
function Bl(e, t = de) {
  Hn("ec", e, t);
}
const kl = "components";
function Ul(e, t) {
  return Wl(kl, e, !0, t) || e;
}
const Kl = Symbol.for("v-ndc");
function Wl(e, t, n = !0, s = !1) {
  const r = be || de;
  if (r) {
    const o = r.type;
    {
      const l = Nc(o, !1);
      if (l && (l === t || l === Le(t) || l === Nn(Le(t)))) return o;
    }
    const i = er(r[e] || o[e], t) || er(r.appContext[e], t);
    return !i && s ? o : i;
  }
}
function er(e, t) {
  return e && (e[t] || e[Le(t)] || e[Nn(Le(t))]);
}
function Fu(e, t, n, s) {
  let r;
  const o = n,
    i = H(e);
  if (i || ue(e)) {
    const l = i && ut(e);
    let c = !1;
    (l && ((c = !Me(e)), (e = $n(e))), (r = new Array(e.length)));
    for (let d = 0, f = e.length; d < f; d++)
      r[d] = t(c ? ge(e[d]) : e[d], d, void 0, o);
  } else if (typeof e == "number") {
    r = new Array(e);
    for (let l = 0; l < e; l++) r[l] = t(l + 1, l, void 0, o);
  } else if (ce(e))
    if (e[Symbol.iterator]) r = Array.from(e, (l, c) => t(l, c, void 0, o));
    else {
      const l = Object.keys(e);
      r = new Array(l.length);
      for (let c = 0, d = l.length; c < d; c++) {
        const f = l[c];
        r[c] = t(e[f], f, c, o);
      }
    }
  else r = [];
  return r;
}
const hs = (e) => (e ? (pi(e) ? kn(e) : hs(e.parent)) : null),
  Gt = he(Object.create(null), {
    $: (e) => e,
    $el: (e) => e.vnode.el,
    $data: (e) => e.data,
    $props: (e) => e.props,
    $attrs: (e) => e.attrs,
    $slots: (e) => e.slots,
    $refs: (e) => e.refs,
    $parent: (e) => hs(e.parent),
    $root: (e) => hs(e.root),
    $host: (e) => e.ce,
    $emit: (e) => e.emit,
    $options: (e) => qo(e),
    $forceUpdate: (e) =>
      e.f ||
      (e.f = () => {
        Vs(e.update);
      }),
    $nextTick: (e) => e.n || (e.n = Hs.bind(e.proxy)),
    $watch: (e) => hc.bind(e),
  }),
  Yn = (e, t) => e !== oe && !e.__isScriptSetup && ee(e, t),
  ql = {
    get({ _: e }, t) {
      if (t === "__v_skip") return !0;
      const {
        ctx: n,
        setupState: s,
        data: r,
        props: o,
        accessCache: i,
        type: l,
        appContext: c,
      } = e;
      let d;
      if (t[0] !== "$") {
        const m = i[t];
        if (m !== void 0)
          switch (m) {
            case 1:
              return s[t];
            case 2:
              return r[t];
            case 4:
              return n[t];
            case 3:
              return o[t];
          }
        else {
          if (Yn(s, t)) return ((i[t] = 1), s[t]);
          if (r !== oe && ee(r, t)) return ((i[t] = 2), r[t]);
          if ((d = e.propsOptions[0]) && ee(d, t)) return ((i[t] = 3), o[t]);
          if (n !== oe && ee(n, t)) return ((i[t] = 4), n[t]);
          ps && (i[t] = 0);
        }
      }
      const f = Gt[t];
      let a, p;
      if (f) return (t === "$attrs" && pe(e.attrs, "get", ""), f(e));
      if ((a = l.__cssModules) && (a = a[t])) return a;
      if (n !== oe && ee(n, t)) return ((i[t] = 4), n[t]);
      if (((p = c.config.globalProperties), ee(p, t))) return p[t];
    },
    set({ _: e }, t, n) {
      const { data: s, setupState: r, ctx: o } = e;
      return Yn(r, t)
        ? ((r[t] = n), !0)
        : s !== oe && ee(s, t)
          ? ((s[t] = n), !0)
          : ee(e.props, t) || (t[0] === "$" && t.slice(1) in e)
            ? !1
            : ((o[t] = n), !0);
    },
    has(
      {
        _: {
          data: e,
          setupState: t,
          accessCache: n,
          ctx: s,
          appContext: r,
          propsOptions: o,
        },
      },
      i,
    ) {
      let l;
      return (
        !!n[i] ||
        (e !== oe && ee(e, i)) ||
        Yn(t, i) ||
        ((l = o[0]) && ee(l, i)) ||
        ee(s, i) ||
        ee(Gt, i) ||
        ee(r.config.globalProperties, i)
      );
    },
    defineProperty(e, t, n) {
      return (
        n.get != null
          ? (e._.accessCache[t] = 0)
          : ee(n, "value") && this.set(e, t, n.value, null),
        Reflect.defineProperty(e, t, n)
      );
    },
  };
function tr(e) {
  return H(e) ? e.reduce((t, n) => ((t[n] = null), t), {}) : e;
}
let ps = !0;
function Gl(e) {
  const t = qo(e),
    n = e.proxy,
    s = e.ctx;
  ((ps = !1), t.beforeCreate && nr(t.beforeCreate, e, "bc"));
  const {
    data: r,
    computed: o,
    methods: i,
    watch: l,
    provide: c,
    inject: d,
    created: f,
    beforeMount: a,
    mounted: p,
    beforeUpdate: m,
    updated: E,
    activated: P,
    deactivated: V,
    beforeDestroy: F,
    beforeUnmount: L,
    destroyed: N,
    unmounted: M,
    render: B,
    renderTracked: ne,
    renderTriggered: G,
    errorCaptured: W,
    serverPrefetch: A,
    expose: U,
    inheritAttrs: Q,
    components: O,
    directives: z,
    filters: ae,
  } = t;
  if ((d && zl(d, s, null), i))
    for (const q in i) {
      const X = i[q];
      K(X) && (s[q] = X.bind(n));
    }
  if (r) {
    const q = r.call(n, n);
    ce(q) && (e.data = fn(q));
  }
  if (((ps = !0), o))
    for (const q in o) {
      const X = o[q],
        Ge = K(X) ? X.bind(n, n) : K(X.get) ? X.get.bind(n, n) : We,
        tt = !K(X) && K(X.set) ? X.set.bind(n) : We,
        De = Ie({ get: Ge, set: tt });
      Object.defineProperty(s, q, {
        enumerable: !0,
        configurable: !0,
        get: () => De.value,
        set: (Se) => (De.value = Se),
      });
    }
  if (l) for (const q in l) Wo(l[q], s, n, q);
  if (c) {
    const q = K(c) ? c.call(n) : c;
    Reflect.ownKeys(q).forEach((X) => {
      _n(X, q[X]);
    });
  }
  f && nr(f, e, "c");
  function se(q, X) {
    H(X) ? X.forEach((Ge) => q(Ge.bind(n))) : X && q(X.bind(n));
  }
  if (
    (se(Fl, a),
    se(ko, p),
    se($l, m),
    se(Dl, E),
    se(Ml, P),
    se(Ll, V),
    se(Bl, W),
    se(Vl, ne),
    se(Hl, G),
    se(Uo, L),
    se(Ko, M),
    se(jl, A),
    H(U))
  )
    if (U.length) {
      const q = e.exposed || (e.exposed = {});
      U.forEach((X) => {
        Object.defineProperty(q, X, {
          get: () => n[X],
          set: (Ge) => (n[X] = Ge),
        });
      });
    } else e.exposed || (e.exposed = {});
  (B && e.render === We && (e.render = B),
    Q != null && (e.inheritAttrs = Q),
    O && (e.components = O),
    z && (e.directives = z),
    A && Vo(e));
}
function zl(e, t, n = We) {
  H(e) && (e = gs(e));
  for (const s in e) {
    const r = e[s];
    let o;
    (ce(r)
      ? "default" in r
        ? (o = qe(r.from || s, r.default, !0))
        : (o = qe(r.from || s))
      : (o = qe(r)),
      fe(o)
        ? Object.defineProperty(t, s, {
            enumerable: !0,
            configurable: !0,
            get: () => o.value,
            set: (i) => (o.value = i),
          })
        : (t[s] = o));
  }
}
function nr(e, t, n) {
  Fe(H(e) ? e.map((s) => s.bind(t.proxy)) : e.bind(t.proxy), t, n);
}
function Wo(e, t, n, s) {
  let r = s.includes(".") ? ii(n, s) : () => n[s];
  if (ue(e)) {
    const o = t[e];
    K(o) && zt(r, o);
  } else if (K(e)) zt(r, e.bind(n));
  else if (ce(e))
    if (H(e)) e.forEach((o) => Wo(o, t, n, s));
    else {
      const o = K(e.handler) ? e.handler.bind(n) : t[e.handler];
      K(o) && zt(r, o, e);
    }
}
function qo(e) {
  const t = e.type,
    { mixins: n, extends: s } = t,
    {
      mixins: r,
      optionsCache: o,
      config: { optionMergeStrategies: i },
    } = e.appContext,
    l = o.get(t);
  let c;
  return (
    l
      ? (c = l)
      : !r.length && !n && !s
        ? (c = t)
        : ((c = {}),
          r.length && r.forEach((d) => An(c, d, i, !0)),
          An(c, t, i)),
    ce(t) && o.set(t, c),
    c
  );
}
function An(e, t, n, s = !1) {
  const { mixins: r, extends: o } = t;
  (o && An(e, o, n, !0), r && r.forEach((i) => An(e, i, n, !0)));
  for (const i in t)
    if (!(s && i === "expose")) {
      const l = Jl[i] || (n && n[i]);
      e[i] = l ? l(e[i], t[i]) : t[i];
    }
  return e;
}
const Jl = {
  data: sr,
  props: rr,
  emits: rr,
  methods: kt,
  computed: kt,
  beforeCreate: ve,
  created: ve,
  beforeMount: ve,
  mounted: ve,
  beforeUpdate: ve,
  updated: ve,
  beforeDestroy: ve,
  beforeUnmount: ve,
  destroyed: ve,
  unmounted: ve,
  activated: ve,
  deactivated: ve,
  errorCaptured: ve,
  serverPrefetch: ve,
  components: kt,
  directives: kt,
  watch: Yl,
  provide: sr,
  inject: Ql,
};
function sr(e, t) {
  return t
    ? e
      ? function () {
          return he(
            K(e) ? e.call(this, this) : e,
            K(t) ? t.call(this, this) : t,
          );
        }
      : t
    : e;
}
function Ql(e, t) {
  return kt(gs(e), gs(t));
}
function gs(e) {
  if (H(e)) {
    const t = {};
    for (let n = 0; n < e.length; n++) t[e[n]] = e[n];
    return t;
  }
  return e;
}
function ve(e, t) {
  return e ? [...new Set([].concat(e, t))] : t;
}
function kt(e, t) {
  return e ? he(Object.create(null), e, t) : t;
}
function rr(e, t) {
  return e
    ? H(e) && H(t)
      ? [...new Set([...e, ...t])]
      : he(Object.create(null), tr(e), tr(t ?? {}))
    : t;
}
function Yl(e, t) {
  if (!e) return t;
  if (!t) return e;
  const n = he(Object.create(null), e);
  for (const s in t) n[s] = ve(e[s], t[s]);
  return n;
}
function Go() {
  return {
    app: null,
    config: {
      isNativeTag: Fi,
      performance: !1,
      globalProperties: {},
      optionMergeStrategies: {},
      errorHandler: void 0,
      warnHandler: void 0,
      compilerOptions: {},
    },
    mixins: [],
    components: {},
    directives: {},
    provides: Object.create(null),
    optionsCache: new WeakMap(),
    propsCache: new WeakMap(),
    emitsCache: new WeakMap(),
  };
}
let Xl = 0;
function Zl(e, t) {
  return function (s, r = null) {
    (K(s) || (s = he({}, s)), r != null && !ce(r) && (r = null));
    const o = Go(),
      i = new WeakSet(),
      l = [];
    let c = !1;
    const d = (o.app = {
      _uid: Xl++,
      _component: s,
      _props: r,
      _container: null,
      _context: o,
      _instance: null,
      version: $c,
      get config() {
        return o.config;
      },
      set config(f) {},
      use(f, ...a) {
        return (
          i.has(f) ||
            (f && K(f.install)
              ? (i.add(f), f.install(d, ...a))
              : K(f) && (i.add(f), f(d, ...a))),
          d
        );
      },
      mixin(f) {
        return (o.mixins.includes(f) || o.mixins.push(f), d);
      },
      component(f, a) {
        return a ? ((o.components[f] = a), d) : o.components[f];
      },
      directive(f, a) {
        return a ? ((o.directives[f] = a), d) : o.directives[f];
      },
      mount(f, a, p) {
        if (!c) {
          const m = d._ceVNode || we(s, r);
          return (
            (m.appContext = o),
            p === !0 ? (p = "svg") : p === !1 && (p = void 0),
            e(m, f, p),
            (c = !0),
            (d._container = f),
            (f.__vue_app__ = d),
            kn(m.component)
          );
        }
      },
      onUnmount(f) {
        l.push(f);
      },
      unmount() {
        c &&
          (Fe(l, d._instance, 16),
          e(null, d._container),
          delete d._container.__vue_app__);
      },
      provide(f, a) {
        return ((o.provides[f] = a), d);
      },
      runWithContext(f) {
        const a = Et;
        Et = d;
        try {
          return f();
        } finally {
          Et = a;
        }
      },
    });
    return d;
  };
}
let Et = null;
function _n(e, t) {
  if (de) {
    let n = de.provides;
    const s = de.parent && de.parent.provides;
    (s === n && (n = de.provides = Object.create(s)), (n[e] = t));
  }
}
function qe(e, t, n = !1) {
  const s = de || be;
  if (s || Et) {
    const r = Et
      ? Et._context.provides
      : s
        ? s.parent == null
          ? s.vnode.appContext && s.vnode.appContext.provides
          : s.parent.provides
        : void 0;
    if (r && e in r) return r[e];
    if (arguments.length > 1) return n && K(t) ? t.call(s && s.proxy) : t;
  }
}
function ec() {
  return !!(de || be || Et);
}
const zo = {},
  Jo = () => Object.create(zo),
  Qo = (e) => Object.getPrototypeOf(e) === zo;
function tc(e, t, n, s = !1) {
  const r = {},
    o = Jo();
  ((e.propsDefaults = Object.create(null)), Yo(e, t, r, o));
  for (const i in e.propsOptions[0]) i in r || (r[i] = void 0);
  (n ? (e.props = s ? r : wo(r)) : e.type.props ? (e.props = r) : (e.props = o),
    (e.attrs = o));
}
function nc(e, t, n, s) {
  const {
      props: r,
      attrs: o,
      vnode: { patchFlag: i },
    } = e,
    l = Y(r),
    [c] = e.propsOptions;
  let d = !1;
  if ((s || i > 0) && !(i & 16)) {
    if (i & 8) {
      const f = e.vnode.dynamicProps;
      for (let a = 0; a < f.length; a++) {
        let p = f[a];
        if (Vn(e.emitsOptions, p)) continue;
        const m = t[p];
        if (c)
          if (ee(o, p)) m !== o[p] && ((o[p] = m), (d = !0));
          else {
            const E = Le(p);
            r[E] = ms(c, l, E, m, e, !1);
          }
        else m !== o[p] && ((o[p] = m), (d = !0));
      }
    }
  } else {
    Yo(e, t, r, o) && (d = !0);
    let f;
    for (const a in l)
      (!t || (!ee(t, a) && ((f = wt(a)) === a || !ee(t, f)))) &&
        (c
          ? n &&
            (n[a] !== void 0 || n[f] !== void 0) &&
            (r[a] = ms(c, l, a, void 0, e, !0))
          : delete r[a]);
    if (o !== l)
      for (const a in o) (!t || !ee(t, a)) && (delete o[a], (d = !0));
  }
  d && Xe(e.attrs, "set", "");
}
function Yo(e, t, n, s) {
  const [r, o] = e.propsOptions;
  let i = !1,
    l;
  if (t)
    for (let c in t) {
      if (Ut(c)) continue;
      const d = t[c];
      let f;
      r && ee(r, (f = Le(c)))
        ? !o || !o.includes(f)
          ? (n[f] = d)
          : ((l || (l = {}))[f] = d)
        : Vn(e.emitsOptions, c) ||
          ((!(c in s) || d !== s[c]) && ((s[c] = d), (i = !0)));
    }
  if (o) {
    const c = Y(n),
      d = l || oe;
    for (let f = 0; f < o.length; f++) {
      const a = o[f];
      n[a] = ms(r, c, a, d[a], e, !ee(d, a));
    }
  }
  return i;
}
function ms(e, t, n, s, r, o) {
  const i = e[n];
  if (i != null) {
    const l = ee(i, "default");
    if (l && s === void 0) {
      const c = i.default;
      if (i.type !== Function && !i.skipFactory && K(c)) {
        const { propsDefaults: d } = r;
        if (n in d) s = d[n];
        else {
          const f = an(r);
          ((s = d[n] = c.call(null, t)), f());
        }
      } else s = c;
      r.ce && r.ce._setProp(n, s);
    }
    i[0] &&
      (o && !l ? (s = !1) : i[1] && (s === "" || s === wt(n)) && (s = !0));
  }
  return s;
}
const sc = new WeakMap();
function Xo(e, t, n = !1) {
  const s = n ? sc : t.propsCache,
    r = s.get(e);
  if (r) return r;
  const o = e.props,
    i = {},
    l = [];
  let c = !1;
  if (!K(e)) {
    const f = (a) => {
      c = !0;
      const [p, m] = Xo(a, t, !0);
      (he(i, p), m && l.push(...m));
    };
    (!n && t.mixins.length && t.mixins.forEach(f),
      e.extends && f(e.extends),
      e.mixins && e.mixins.forEach(f));
  }
  if (!o && !c) return (ce(e) && s.set(e, Mt), Mt);
  if (H(o))
    for (let f = 0; f < o.length; f++) {
      const a = Le(o[f]);
      or(a) && (i[a] = oe);
    }
  else if (o)
    for (const f in o) {
      const a = Le(f);
      if (or(a)) {
        const p = o[f],
          m = (i[a] = H(p) || K(p) ? { type: p } : he({}, p)),
          E = m.type;
        let P = !1,
          V = !0;
        if (H(E))
          for (let F = 0; F < E.length; ++F) {
            const L = E[F],
              N = K(L) && L.name;
            if (N === "Boolean") {
              P = !0;
              break;
            } else N === "String" && (V = !1);
          }
        else P = K(E) && E.name === "Boolean";
        ((m[0] = P), (m[1] = V), (P || ee(m, "default")) && l.push(a));
      }
    }
  const d = [i, l];
  return (ce(e) && s.set(e, d), d);
}
function or(e) {
  return e[0] !== "$" && !Ut(e);
}
const Zo = (e) => e[0] === "_" || e === "$stable",
  Bs = (e) => (H(e) ? e.map(Ke) : [Ke(e)]),
  rc = (e, t, n) => {
    if (t._n) return t;
    const s = Pl((...r) => Bs(t(...r)), n);
    return ((s._c = !1), s);
  },
  ei = (e, t, n) => {
    const s = e._ctx;
    for (const r in e) {
      if (Zo(r)) continue;
      const o = e[r];
      if (K(o)) t[r] = rc(r, o, s);
      else if (o != null) {
        const i = Bs(o);
        t[r] = () => i;
      }
    }
  },
  ti = (e, t) => {
    const n = Bs(t);
    e.slots.default = () => n;
  },
  ni = (e, t, n) => {
    for (const s in t) (n || s !== "_") && (e[s] = t[s]);
  },
  oc = (e, t, n) => {
    const s = (e.slots = Jo());
    if (e.vnode.shapeFlag & 32) {
      const r = t._;
      r ? (ni(s, t, n), n && no(s, "_", r, !0)) : ei(t, s);
    } else t && ti(e, t);
  },
  ic = (e, t, n) => {
    const { vnode: s, slots: r } = e;
    let o = !0,
      i = oe;
    if (s.shapeFlag & 32) {
      const l = t._;
      (l
        ? n && l === 1
          ? (o = !1)
          : ni(r, t, n)
        : ((o = !t.$stable), ei(t, r)),
        (i = t));
    } else t && (ti(e, t), (i = { default: 1 }));
    if (o) for (const l in r) !Zo(l) && i[l] == null && delete r[l];
  },
  Pe = bc;
function lc(e) {
  return cc(e);
}
function cc(e, t) {
  const n = Fn();
  n.__VUE__ = !0;
  const {
      insert: s,
      remove: r,
      patchProp: o,
      createElement: i,
      createText: l,
      createComment: c,
      setText: d,
      setElementText: f,
      parentNode: a,
      nextSibling: p,
      setScopeId: m = We,
      insertStaticContent: E,
    } = e,
    P = (
      u,
      h,
      g,
      v = null,
      b = null,
      _ = null,
      C = void 0,
      w = null,
      x = !!h.dynamicChildren,
    ) => {
      if (u === h) return;
      (u && !bt(u, h) && ((v = y(u)), Se(u, b, _, !0), (u = null)),
        h.patchFlag === -2 && ((x = !1), (h.dynamicChildren = null)));
      const { type: S, ref: j, shapeFlag: T } = h;
      switch (S) {
        case Bn:
          V(u, h, g, v);
          break;
        case xe:
          F(u, h, g, v);
          break;
        case bn:
          u == null && L(h, g, v, C);
          break;
        case Ue:
          O(u, h, g, v, b, _, C, w, x);
          break;
        default:
          T & 1
            ? B(u, h, g, v, b, _, C, w, x)
            : T & 6
              ? z(u, h, g, v, b, _, C, w, x)
              : (T & 64 || T & 128) && S.process(u, h, g, v, b, _, C, w, x, $);
      }
      j != null && b && Pn(j, u && u.ref, _, h || u, !h);
    },
    V = (u, h, g, v) => {
      if (u == null) s((h.el = l(h.children)), g, v);
      else {
        const b = (h.el = u.el);
        h.children !== u.children && d(b, h.children);
      }
    },
    F = (u, h, g, v) => {
      u == null ? s((h.el = c(h.children || "")), g, v) : (h.el = u.el);
    },
    L = (u, h, g, v) => {
      [u.el, u.anchor] = E(u.children, h, g, v, u.el, u.anchor);
    },
    N = ({ el: u, anchor: h }, g, v) => {
      let b;
      for (; u && u !== h;) ((b = p(u)), s(u, g, v), (u = b));
      s(h, g, v);
    },
    M = ({ el: u, anchor: h }) => {
      let g;
      for (; u && u !== h;) ((g = p(u)), r(u), (u = g));
      r(h);
    },
    B = (u, h, g, v, b, _, C, w, x) => {
      (h.type === "svg" ? (C = "svg") : h.type === "math" && (C = "mathml"),
        u == null ? ne(h, g, v, b, _, C, w, x) : A(u, h, b, _, C, w, x));
    },
    ne = (u, h, g, v, b, _, C, w) => {
      let x, S;
      const { props: j, shapeFlag: T, transition: D, dirs: k } = u;
      if (
        ((x = u.el = i(u.type, _, j && j.is, j)),
        T & 8
          ? f(x, u.children)
          : T & 16 && W(u.children, x, null, v, b, Xn(u, _), C, w),
        k && gt(u, null, v, "created"),
        G(x, u, u.scopeId, C, v),
        j)
      ) {
        for (const ie in j)
          ie !== "value" && !Ut(ie) && o(x, ie, null, j[ie], _, v);
        ("value" in j && o(x, "value", null, j.value, _),
          (S = j.onVnodeBeforeMount) && Be(S, v, u));
      }
      k && gt(u, null, v, "beforeMount");
      const J = fc(b, D);
      (J && D.beforeEnter(x),
        s(x, h, g),
        ((S = j && j.onVnodeMounted) || J || k) &&
          Pe(() => {
            (S && Be(S, v, u), J && D.enter(x), k && gt(u, null, v, "mounted"));
          }, b));
    },
    G = (u, h, g, v, b) => {
      if ((g && m(u, g), v)) for (let _ = 0; _ < v.length; _++) m(u, v[_]);
      if (b) {
        let _ = b.subTree;
        if (
          h === _ ||
          (ci(_.type) && (_.ssContent === h || _.ssFallback === h))
        ) {
          const C = b.vnode;
          G(u, C, C.scopeId, C.slotScopeIds, b.parent);
        }
      }
    },
    W = (u, h, g, v, b, _, C, w, x = 0) => {
      for (let S = x; S < u.length; S++) {
        const j = (u[S] = w ? lt(u[S]) : Ke(u[S]));
        P(null, j, h, g, v, b, _, C, w);
      }
    },
    A = (u, h, g, v, b, _, C) => {
      const w = (h.el = u.el);
      let { patchFlag: x, dynamicChildren: S, dirs: j } = h;
      x |= u.patchFlag & 16;
      const T = u.props || oe,
        D = h.props || oe;
      let k;
      if (
        (g && mt(g, !1),
        (k = D.onVnodeBeforeUpdate) && Be(k, g, h, u),
        j && gt(h, u, g, "beforeUpdate"),
        g && mt(g, !0),
        ((T.innerHTML && D.innerHTML == null) ||
          (T.textContent && D.textContent == null)) &&
          f(w, ""),
        S
          ? U(u.dynamicChildren, S, w, g, v, Xn(h, b), _)
          : C || X(u, h, w, null, g, v, Xn(h, b), _, !1),
        x > 0)
      ) {
        if (x & 16) Q(w, T, D, g, b);
        else if (
          (x & 2 && T.class !== D.class && o(w, "class", null, D.class, b),
          x & 4 && o(w, "style", T.style, D.style, b),
          x & 8)
        ) {
          const J = h.dynamicProps;
          for (let ie = 0; ie < J.length; ie++) {
            const te = J[ie],
              Ce = T[te],
              Ee = D[te];
            (Ee !== Ce || te === "value") && o(w, te, Ce, Ee, b, g);
          }
        }
        x & 1 && u.children !== h.children && f(w, h.children);
      } else !C && S == null && Q(w, T, D, g, b);
      ((k = D.onVnodeUpdated) || j) &&
        Pe(() => {
          (k && Be(k, g, h, u), j && gt(h, u, g, "updated"));
        }, v);
    },
    U = (u, h, g, v, b, _, C) => {
      for (let w = 0; w < h.length; w++) {
        const x = u[w],
          S = h[w],
          j =
            x.el && (x.type === Ue || !bt(x, S) || x.shapeFlag & 70)
              ? a(x.el)
              : g;
        P(x, S, j, null, v, b, _, C, !0);
      }
    },
    Q = (u, h, g, v, b) => {
      if (h !== g) {
        if (h !== oe)
          for (const _ in h) !Ut(_) && !(_ in g) && o(u, _, h[_], null, b, v);
        for (const _ in g) {
          if (Ut(_)) continue;
          const C = g[_],
            w = h[_];
          C !== w && _ !== "value" && o(u, _, w, C, b, v);
        }
        "value" in g && o(u, "value", h.value, g.value, b);
      }
    },
    O = (u, h, g, v, b, _, C, w, x) => {
      const S = (h.el = u ? u.el : l("")),
        j = (h.anchor = u ? u.anchor : l(""));
      let { patchFlag: T, dynamicChildren: D, slotScopeIds: k } = h;
      (k && (w = w ? w.concat(k) : k),
        u == null
          ? (s(S, g, v), s(j, g, v), W(h.children || [], g, j, b, _, C, w, x))
          : T > 0 && T & 64 && D && u.dynamicChildren
            ? (U(u.dynamicChildren, D, g, b, _, C, w),
              (h.key != null || (b && h === b.subTree)) && si(u, h, !0))
            : X(u, h, g, j, b, _, C, w, x));
    },
    z = (u, h, g, v, b, _, C, w, x) => {
      ((h.slotScopeIds = w),
        u == null
          ? h.shapeFlag & 512
            ? b.ctx.activate(h, g, v, C, x)
            : ae(h, g, v, b, _, C, x)
          : me(u, h, x));
    },
    ae = (u, h, g, v, b, _, C) => {
      const w = (u.component = Ac(u, v, b));
      if ((jn(u) && (w.ctx.renderer = $), Oc(w, !1, C), w.asyncDep)) {
        if ((b && b.registerDep(w, se, C), !u.el)) {
          const x = (w.subTree = we(xe));
          F(null, x, h, g);
        }
      } else se(w, u, h, g, b, _, C);
    },
    me = (u, h, g) => {
      const v = (h.component = u.component);
      if (yc(u, h, g))
        if (v.asyncDep && !v.asyncResolved) {
          q(v, h, g);
          return;
        } else ((v.next = h), v.update());
      else ((h.el = u.el), (v.vnode = h));
    },
    se = (u, h, g, v, b, _, C) => {
      const w = () => {
        if (u.isMounted) {
          let { next: T, bu: D, u: k, parent: J, vnode: ie } = u;
          {
            const He = ri(u);
            if (He) {
              (T && ((T.el = ie.el), q(u, T, C)),
                He.asyncDep.then(() => {
                  u.isUnmounted || w();
                }));
              return;
            }
          }
          let te = T,
            Ce;
          (mt(u, !1),
            T ? ((T.el = ie.el), q(u, T, C)) : (T = ie),
            D && yn(D),
            (Ce = T.props && T.props.onVnodeBeforeUpdate) && Be(Ce, J, T, ie),
            mt(u, !0));
          const Ee = lr(u),
            je = u.subTree;
          ((u.subTree = Ee),
            P(je, Ee, a(je.el), y(je), u, b, _),
            (T.el = Ee.el),
            te === null && _c(u, Ee.el),
            k && Pe(k, b),
            (Ce = T.props && T.props.onVnodeUpdated) &&
              Pe(() => Be(Ce, J, T, ie), b));
        } else {
          let T;
          const { el: D, props: k } = h,
            { bm: J, m: ie, parent: te, root: Ce, type: Ee } = u,
            je = qt(h);
          (mt(u, !1),
            J && yn(J),
            !je && (T = k && k.onVnodeBeforeMount) && Be(T, te, h),
            mt(u, !0));
          {
            Ce.ce && Ce.ce._injectChildStyle(Ee);
            const He = (u.subTree = lr(u));
            (P(null, He, g, v, u, b, _), (h.el = He.el));
          }
          if ((ie && Pe(ie, b), !je && (T = k && k.onVnodeMounted))) {
            const He = h;
            Pe(() => Be(T, te, He), b);
          }
          ((h.shapeFlag & 256 ||
            (te && qt(te.vnode) && te.vnode.shapeFlag & 256)) &&
            u.a &&
            Pe(u.a, b),
            (u.isMounted = !0),
            (h = g = v = null));
        }
      };
      u.scope.on();
      const x = (u.effect = new fo(w));
      u.scope.off();
      const S = (u.update = x.run.bind(x)),
        j = (u.job = x.runIfDirty.bind(x));
      ((j.i = u), (j.id = u.uid), (x.scheduler = () => Vs(j)), mt(u, !0), S());
    },
    q = (u, h, g) => {
      h.component = u;
      const v = u.vnode.props;
      ((u.vnode = h),
        (u.next = null),
        nc(u, h.props, v, g),
        ic(u, h.children, g),
        ht(),
        Xs(u),
        pt());
    },
    X = (u, h, g, v, b, _, C, w, x = !1) => {
      const S = u && u.children,
        j = u ? u.shapeFlag : 0,
        T = h.children,
        { patchFlag: D, shapeFlag: k } = h;
      if (D > 0) {
        if (D & 128) {
          tt(S, T, g, v, b, _, C, w, x);
          return;
        } else if (D & 256) {
          Ge(S, T, g, v, b, _, C, w, x);
          return;
        }
      }
      k & 8
        ? (j & 16 && Te(S, b, _), T !== S && f(g, T))
        : j & 16
          ? k & 16
            ? tt(S, T, g, v, b, _, C, w, x)
            : Te(S, b, _, !0)
          : (j & 8 && f(g, ""), k & 16 && W(T, g, v, b, _, C, w, x));
    },
    Ge = (u, h, g, v, b, _, C, w, x) => {
      ((u = u || Mt), (h = h || Mt));
      const S = u.length,
        j = h.length,
        T = Math.min(S, j);
      let D;
      for (D = 0; D < T; D++) {
        const k = (h[D] = x ? lt(h[D]) : Ke(h[D]));
        P(u[D], k, g, null, b, _, C, w, x);
      }
      S > j ? Te(u, b, _, !0, !1, T) : W(h, g, v, b, _, C, w, x, T);
    },
    tt = (u, h, g, v, b, _, C, w, x) => {
      let S = 0;
      const j = h.length;
      let T = u.length - 1,
        D = j - 1;
      for (; S <= T && S <= D;) {
        const k = u[S],
          J = (h[S] = x ? lt(h[S]) : Ke(h[S]));
        if (bt(k, J)) P(k, J, g, null, b, _, C, w, x);
        else break;
        S++;
      }
      for (; S <= T && S <= D;) {
        const k = u[T],
          J = (h[D] = x ? lt(h[D]) : Ke(h[D]));
        if (bt(k, J)) P(k, J, g, null, b, _, C, w, x);
        else break;
        (T--, D--);
      }
      if (S > T) {
        if (S <= D) {
          const k = D + 1,
            J = k < j ? h[k].el : v;
          for (; S <= D;)
            (P(null, (h[S] = x ? lt(h[S]) : Ke(h[S])), g, J, b, _, C, w, x),
              S++);
        }
      } else if (S > D) for (; S <= T;) (Se(u[S], b, _, !0), S++);
      else {
        const k = S,
          J = S,
          ie = new Map();
        for (S = J; S <= D; S++) {
          const Re = (h[S] = x ? lt(h[S]) : Ke(h[S]));
          Re.key != null && ie.set(Re.key, S);
        }
        let te,
          Ce = 0;
        const Ee = D - J + 1;
        let je = !1,
          He = 0;
        const jt = new Array(Ee);
        for (S = 0; S < Ee; S++) jt[S] = 0;
        for (S = k; S <= T; S++) {
          const Re = u[S];
          if (Ce >= Ee) {
            Se(Re, b, _, !0);
            continue;
          }
          let Ve;
          if (Re.key != null) Ve = ie.get(Re.key);
          else
            for (te = J; te <= D; te++)
              if (jt[te - J] === 0 && bt(Re, h[te])) {
                Ve = te;
                break;
              }
          Ve === void 0
            ? Se(Re, b, _, !0)
            : ((jt[Ve - J] = S + 1),
              Ve >= He ? (He = Ve) : (je = !0),
              P(Re, h[Ve], g, null, b, _, C, w, x),
              Ce++);
        }
        const Gs = je ? uc(jt) : Mt;
        for (te = Gs.length - 1, S = Ee - 1; S >= 0; S--) {
          const Re = J + S,
            Ve = h[Re],
            zs = Re + 1 < j ? h[Re + 1].el : v;
          jt[S] === 0
            ? P(null, Ve, g, zs, b, _, C, w, x)
            : je && (te < 0 || S !== Gs[te] ? De(Ve, g, zs, 2) : te--);
        }
      }
    },
    De = (u, h, g, v, b = null) => {
      const { el: _, type: C, transition: w, children: x, shapeFlag: S } = u;
      if (S & 6) {
        De(u.component.subTree, h, g, v);
        return;
      }
      if (S & 128) {
        u.suspense.move(h, g, v);
        return;
      }
      if (S & 64) {
        C.move(u, h, g, $);
        return;
      }
      if (C === Ue) {
        s(_, h, g);
        for (let T = 0; T < x.length; T++) De(x[T], h, g, v);
        s(u.anchor, h, g);
        return;
      }
      if (C === bn) {
        N(u, h, g);
        return;
      }
      if (v !== 2 && S & 1 && w)
        if (v === 0) (w.beforeEnter(_), s(_, h, g), Pe(() => w.enter(_), b));
        else {
          const { leave: T, delayLeave: D, afterLeave: k } = w,
            J = () => s(_, h, g),
            ie = () => {
              T(_, () => {
                (J(), k && k());
              });
            };
          D ? D(_, J, ie) : ie();
        }
      else s(_, h, g);
    },
    Se = (u, h, g, v = !1, b = !1) => {
      const {
        type: _,
        props: C,
        ref: w,
        children: x,
        dynamicChildren: S,
        shapeFlag: j,
        patchFlag: T,
        dirs: D,
        cacheIndex: k,
      } = u;
      if (
        (T === -2 && (b = !1),
        w != null && Pn(w, null, g, u, !0),
        k != null && (h.renderCache[k] = void 0),
        j & 256)
      ) {
        h.ctx.deactivate(u);
        return;
      }
      const J = j & 1 && D,
        ie = !qt(u);
      let te;
      if ((ie && (te = C && C.onVnodeBeforeUnmount) && Be(te, h, u), j & 6))
        dn(u.component, g, v);
      else {
        if (j & 128) {
          u.suspense.unmount(g, v);
          return;
        }
        (J && gt(u, null, h, "beforeUnmount"),
          j & 64
            ? u.type.remove(u, h, g, $, v)
            : S && !S.hasOnce && (_ !== Ue || (T > 0 && T & 64))
              ? Te(S, h, g, !1, !0)
              : ((_ === Ue && T & 384) || (!b && j & 16)) && Te(x, h, g),
          v && Ct(u));
      }
      ((ie && (te = C && C.onVnodeUnmounted)) || J) &&
        Pe(() => {
          (te && Be(te, h, u), J && gt(u, null, h, "unmounted"));
        }, g);
    },
    Ct = (u) => {
      const { type: h, el: g, anchor: v, transition: b } = u;
      if (h === Ue) {
        Rt(g, v);
        return;
      }
      if (h === bn) {
        M(u);
        return;
      }
      const _ = () => {
        (r(g), b && !b.persisted && b.afterLeave && b.afterLeave());
      };
      if (u.shapeFlag & 1 && b && !b.persisted) {
        const { leave: C, delayLeave: w } = b,
          x = () => C(g, _);
        w ? w(u.el, _, x) : x();
      } else _();
    },
    Rt = (u, h) => {
      let g;
      for (; u !== h;) ((g = p(u)), r(u), (u = g));
      r(h);
    },
    dn = (u, h, g) => {
      const { bum: v, scope: b, job: _, subTree: C, um: w, m: x, a: S } = u;
      (ir(x),
        ir(S),
        v && yn(v),
        b.stop(),
        _ && ((_.flags |= 8), Se(C, u, h, g)),
        w && Pe(w, h),
        Pe(() => {
          u.isUnmounted = !0;
        }, h),
        h &&
          h.pendingBranch &&
          !h.isUnmounted &&
          u.asyncDep &&
          !u.asyncResolved &&
          u.suspenseId === h.pendingId &&
          (h.deps--, h.deps === 0 && h.resolve()));
    },
    Te = (u, h, g, v = !1, b = !1, _ = 0) => {
      for (let C = _; C < u.length; C++) Se(u[C], h, g, v, b);
    },
    y = (u) => {
      if (u.shapeFlag & 6) return y(u.component.subTree);
      if (u.shapeFlag & 128) return u.suspense.next();
      const h = p(u.anchor || u.el),
        g = h && h[Al];
      return g ? p(g) : h;
    };
  let I = !1;
  const R = (u, h, g) => {
      (u == null
        ? h._vnode && Se(h._vnode, null, null, !0)
        : P(h._vnode || null, u, h, null, null, null, g),
        (h._vnode = u),
        I || ((I = !0), Xs(), Oo(), (I = !1)));
    },
    $ = {
      p: P,
      um: Se,
      m: De,
      r: Ct,
      mt: ae,
      mc: W,
      pc: X,
      pbc: U,
      n: y,
      o: e,
    };
  return { render: R, hydrate: void 0, createApp: Zl(R) };
}
function Xn({ type: e, props: t }, n) {
  return (n === "svg" && e === "foreignObject") ||
    (n === "mathml" &&
      e === "annotation-xml" &&
      t &&
      t.encoding &&
      t.encoding.includes("html"))
    ? void 0
    : n;
}
function mt({ effect: e, job: t }, n) {
  n ? ((e.flags |= 32), (t.flags |= 4)) : ((e.flags &= -33), (t.flags &= -5));
}
function fc(e, t) {
  return (!e || (e && !e.pendingBranch)) && t && !t.persisted;
}
function si(e, t, n = !1) {
  const s = e.children,
    r = t.children;
  if (H(s) && H(r))
    for (let o = 0; o < s.length; o++) {
      const i = s[o];
      let l = r[o];
      (l.shapeFlag & 1 &&
        !l.dynamicChildren &&
        ((l.patchFlag <= 0 || l.patchFlag === 32) &&
          ((l = r[o] = lt(r[o])), (l.el = i.el)),
        !n && l.patchFlag !== -2 && si(i, l)),
        l.type === Bn && (l.el = i.el));
    }
}
function uc(e) {
  const t = e.slice(),
    n = [0];
  let s, r, o, i, l;
  const c = e.length;
  for (s = 0; s < c; s++) {
    const d = e[s];
    if (d !== 0) {
      if (((r = n[n.length - 1]), e[r] < d)) {
        ((t[s] = r), n.push(s));
        continue;
      }
      for (o = 0, i = n.length - 1; o < i;)
        ((l = (o + i) >> 1), e[n[l]] < d ? (o = l + 1) : (i = l));
      d < e[n[o]] && (o > 0 && (t[s] = n[o - 1]), (n[o] = s));
    }
  }
  for (o = n.length, i = n[o - 1]; o-- > 0;) ((n[o] = i), (i = t[i]));
  return n;
}
function ri(e) {
  const t = e.subTree.component;
  if (t) return t.asyncDep && !t.asyncResolved ? t : ri(t);
}
function ir(e) {
  if (e) for (let t = 0; t < e.length; t++) e[t].flags |= 8;
}
const ac = Symbol.for("v-scx"),
  dc = () => qe(ac);
function zt(e, t, n) {
  return oi(e, t, n);
}
function oi(e, t, n = oe) {
  const { immediate: s, deep: r, flush: o, once: i } = n,
    l = he({}, n),
    c = (t && s) || (!t && o !== "post");
  let d;
  if (rn) {
    if (o === "sync") {
      const m = dc();
      d = m.__watcherHandles || (m.__watcherHandles = []);
    } else if (!c) {
      const m = () => {};
      return ((m.stop = We), (m.resume = We), (m.pause = We), m);
    }
  }
  const f = de;
  l.call = (m, E, P) => Fe(m, f, E, P);
  let a = !1;
  (o === "post"
    ? (l.scheduler = (m) => {
        Pe(m, f && f.suspense);
      })
    : o !== "sync" &&
      ((a = !0),
      (l.scheduler = (m, E) => {
        E ? m() : Vs(m);
      })),
    (l.augmentJob = (m) => {
      (t && (m.flags |= 4),
        a && ((m.flags |= 2), f && ((m.id = f.uid), (m.i = f))));
    }));
  const p = xl(e, t, l);
  return (rn && (d ? d.push(p) : c && p()), p);
}
function hc(e, t, n) {
  const s = this.proxy,
    r = ue(e) ? (e.includes(".") ? ii(s, e) : () => s[e]) : e.bind(s, s);
  let o;
  K(t) ? (o = t) : ((o = t.handler), (n = t));
  const i = an(this),
    l = oi(r, o.bind(s), n);
  return (i(), l);
}
function ii(e, t) {
  const n = t.split(".");
  return () => {
    let s = e;
    for (let r = 0; r < n.length && s; r++) s = s[n[r]];
    return s;
  };
}
const pc = (e, t) =>
  t === "modelValue" || t === "model-value"
    ? e.modelModifiers
    : e[`${t}Modifiers`] || e[`${Le(t)}Modifiers`] || e[`${wt(t)}Modifiers`];
function gc(e, t, ...n) {
  if (e.isUnmounted) return;
  const s = e.vnode.props || oe;
  let r = n;
  const o = t.startsWith("update:"),
    i = o && pc(s, t.slice(7));
  i &&
    (i.trim && (r = n.map((f) => (ue(f) ? f.trim() : f))),
    i.number && (r = n.map(ls)));
  let l,
    c = s[(l = Wn(t))] || s[(l = Wn(Le(t)))];
  (!c && o && (c = s[(l = Wn(wt(t)))]), c && Fe(c, e, 6, r));
  const d = s[l + "Once"];
  if (d) {
    if (!e.emitted) e.emitted = {};
    else if (e.emitted[l]) return;
    ((e.emitted[l] = !0), Fe(d, e, 6, r));
  }
}
function li(e, t, n = !1) {
  const s = t.emitsCache,
    r = s.get(e);
  if (r !== void 0) return r;
  const o = e.emits;
  let i = {},
    l = !1;
  if (!K(e)) {
    const c = (d) => {
      const f = li(d, t, !0);
      f && ((l = !0), he(i, f));
    };
    (!n && t.mixins.length && t.mixins.forEach(c),
      e.extends && c(e.extends),
      e.mixins && e.mixins.forEach(c));
  }
  return !o && !l
    ? (ce(e) && s.set(e, null), null)
    : (H(o) ? o.forEach((c) => (i[c] = null)) : he(i, o),
      ce(e) && s.set(e, i),
      i);
}
function Vn(e, t) {
  return !e || !In(t)
    ? !1
    : ((t = t.slice(2).replace(/Once$/, "")),
      ee(e, t[0].toLowerCase() + t.slice(1)) || ee(e, wt(t)) || ee(e, t));
}
function lr(e) {
  const {
      type: t,
      vnode: n,
      proxy: s,
      withProxy: r,
      propsOptions: [o],
      slots: i,
      attrs: l,
      emit: c,
      render: d,
      renderCache: f,
      props: a,
      data: p,
      setupState: m,
      ctx: E,
      inheritAttrs: P,
    } = e,
    V = Rn(e);
  let F, L;
  try {
    if (n.shapeFlag & 4) {
      const M = r || s,
        B = M;
      ((F = Ke(d.call(B, M, f, a, m, p, E))), (L = l));
    } else {
      const M = t;
      ((F = Ke(
        M.length > 1 ? M(a, { attrs: l, slots: i, emit: c }) : M(a, null),
      )),
        (L = t.props ? l : mc(l)));
    }
  } catch (M) {
    ((Jt.length = 0), Dn(M, e, 1), (F = we(xe)));
  }
  let N = F;
  if (L && P !== !1) {
    const M = Object.keys(L),
      { shapeFlag: B } = N;
    M.length &&
      B & 7 &&
      (o && M.some(Cs) && (L = vc(L, o)), (N = at(N, L, !1, !0)));
  }
  return (
    n.dirs &&
      ((N = at(N, null, !1, !0)),
      (N.dirs = N.dirs ? N.dirs.concat(n.dirs) : n.dirs)),
    n.transition && nn(N, n.transition),
    (F = N),
    Rn(V),
    F
  );
}
const mc = (e) => {
    let t;
    for (const n in e)
      (n === "class" || n === "style" || In(n)) && ((t || (t = {}))[n] = e[n]);
    return t;
  },
  vc = (e, t) => {
    const n = {};
    for (const s in e) (!Cs(s) || !(s.slice(9) in t)) && (n[s] = e[s]);
    return n;
  };
function yc(e, t, n) {
  const { props: s, children: r, component: o } = e,
    { props: i, children: l, patchFlag: c } = t,
    d = o.emitsOptions;
  if (t.dirs || t.transition) return !0;
  if (n && c >= 0) {
    if (c & 1024) return !0;
    if (c & 16) return s ? cr(s, i, d) : !!i;
    if (c & 8) {
      const f = t.dynamicProps;
      for (let a = 0; a < f.length; a++) {
        const p = f[a];
        if (i[p] !== s[p] && !Vn(d, p)) return !0;
      }
    }
  } else
    return (r || l) && (!l || !l.$stable)
      ? !0
      : s === i
        ? !1
        : s
          ? i
            ? cr(s, i, d)
            : !0
          : !!i;
  return !1;
}
function cr(e, t, n) {
  const s = Object.keys(t);
  if (s.length !== Object.keys(e).length) return !0;
  for (let r = 0; r < s.length; r++) {
    const o = s[r];
    if (t[o] !== e[o] && !Vn(n, o)) return !0;
  }
  return !1;
}
function _c({ vnode: e, parent: t }, n) {
  for (; t;) {
    const s = t.subTree;
    if ((s.suspense && s.suspense.activeBranch === e && (s.el = e.el), s === e))
      (((e = t.vnode).el = n), (t = t.parent));
    else break;
  }
}
const ci = (e) => e.__isSuspense;
function bc(e, t) {
  t && t.pendingBranch
    ? H(e)
      ? t.effects.push(...e)
      : t.effects.push(e)
    : Rl(e);
}
const Ue = Symbol.for("v-fgt"),
  Bn = Symbol.for("v-txt"),
  xe = Symbol.for("v-cmt"),
  bn = Symbol.for("v-stc"),
  Jt = [];
let Ae = null;
function fi(e = !1) {
  Jt.push((Ae = e ? null : []));
}
function Sc() {
  (Jt.pop(), (Ae = Jt[Jt.length - 1] || null));
}
let sn = 1;
function fr(e, t = !1) {
  ((sn += e), e < 0 && Ae && t && (Ae.hasOnce = !0));
}
function ui(e) {
  return (
    (e.dynamicChildren = sn > 0 ? Ae || Mt : null),
    Sc(),
    sn > 0 && Ae && Ae.push(e),
    e
  );
}
function $u(e, t, n, s, r, o) {
  return ui(hi(e, t, n, s, r, o, !0));
}
function ai(e, t, n, s, r) {
  return ui(we(e, t, n, s, r, !0));
}
function Tn(e) {
  return e ? e.__v_isVNode === !0 : !1;
}
function bt(e, t) {
  return e.type === t.type && e.key === t.key;
}
const di = ({ key: e }) => e ?? null,
  Sn = ({ ref: e, ref_key: t, ref_for: n }) => (
    typeof e == "number" && (e = "" + e),
    e != null
      ? ue(e) || fe(e) || K(e)
        ? { i: be, r: e, k: t, f: !!n }
        : e
      : null
  );
function hi(
  e,
  t = null,
  n = null,
  s = 0,
  r = null,
  o = e === Ue ? 0 : 1,
  i = !1,
  l = !1,
) {
  const c = {
    __v_isVNode: !0,
    __v_skip: !0,
    type: e,
    props: t,
    key: t && di(t),
    ref: t && Sn(t),
    scopeId: Mo,
    slotScopeIds: null,
    children: n,
    component: null,
    suspense: null,
    ssContent: null,
    ssFallback: null,
    dirs: null,
    transition: null,
    el: null,
    anchor: null,
    target: null,
    targetStart: null,
    targetAnchor: null,
    staticCount: 0,
    shapeFlag: o,
    patchFlag: s,
    dynamicProps: r,
    dynamicChildren: null,
    appContext: null,
    ctx: be,
  };
  return (
    l
      ? (ks(c, n), o & 128 && e.normalize(c))
      : n && (c.shapeFlag |= ue(n) ? 8 : 16),
    sn > 0 &&
      !i &&
      Ae &&
      (c.patchFlag > 0 || o & 6) &&
      c.patchFlag !== 32 &&
      Ae.push(c),
    c
  );
}
const we = Ec;
function Ec(e, t = null, n = null, s = 0, r = null, o = !1) {
  if (((!e || e === Kl) && (e = xe), Tn(e))) {
    const l = at(e, t, !0);
    return (
      n && ks(l, n),
      sn > 0 &&
        !o &&
        Ae &&
        (l.shapeFlag & 6 ? (Ae[Ae.indexOf(e)] = l) : Ae.push(l)),
      (l.patchFlag = -2),
      l
    );
  }
  if ((Fc(e) && (e = e.__vccOpts), t)) {
    t = xc(t);
    let { class: l, style: c } = t;
    (l && !ue(l) && (t.class = Ts(l)),
      ce(c) && ($s(c) && !H(c) && (c = he({}, c)), (t.style = As(c))));
  }
  const i = ue(e) ? 1 : ci(e) ? 128 : Lo(e) ? 64 : ce(e) ? 4 : K(e) ? 2 : 0;
  return hi(e, t, n, s, r, i, o, !0);
}
function xc(e) {
  return e ? ($s(e) || Qo(e) ? he({}, e) : e) : null;
}
function at(e, t, n = !1, s = !1) {
  const { props: r, ref: o, patchFlag: i, children: l, transition: c } = e,
    d = t ? Cc(r || {}, t) : r,
    f = {
      __v_isVNode: !0,
      __v_skip: !0,
      type: e.type,
      props: d,
      key: d && di(d),
      ref:
        t && t.ref
          ? n && o
            ? H(o)
              ? o.concat(Sn(t))
              : [o, Sn(t)]
            : Sn(t)
          : o,
      scopeId: e.scopeId,
      slotScopeIds: e.slotScopeIds,
      children: l,
      target: e.target,
      targetStart: e.targetStart,
      targetAnchor: e.targetAnchor,
      staticCount: e.staticCount,
      shapeFlag: e.shapeFlag,
      patchFlag: t && e.type !== Ue ? (i === -1 ? 16 : i | 16) : i,
      dynamicProps: e.dynamicProps,
      dynamicChildren: e.dynamicChildren,
      appContext: e.appContext,
      dirs: e.dirs,
      transition: c,
      component: e.component,
      suspense: e.suspense,
      ssContent: e.ssContent && at(e.ssContent),
      ssFallback: e.ssFallback && at(e.ssFallback),
      el: e.el,
      anchor: e.anchor,
      ctx: e.ctx,
      ce: e.ce,
    };
  return (c && s && nn(f, c.clone(f)), f);
}
function wc(e = " ", t = 0) {
  return we(Bn, null, e, t);
}
function Du(e, t) {
  const n = we(bn, null, e);
  return ((n.staticCount = t), n);
}
function ju(e = "", t = !1) {
  return t ? (fi(), ai(xe, null, e)) : we(xe, null, e);
}
function Ke(e) {
  return e == null || typeof e == "boolean"
    ? we(xe)
    : H(e)
      ? we(Ue, null, e.slice())
      : Tn(e)
        ? lt(e)
        : we(Bn, null, String(e));
}
function lt(e) {
  return (e.el === null && e.patchFlag !== -1) || e.memo ? e : at(e);
}
function ks(e, t) {
  let n = 0;
  const { shapeFlag: s } = e;
  if (t == null) t = null;
  else if (H(t)) n = 16;
  else if (typeof t == "object")
    if (s & 65) {
      const r = t.default;
      r && (r._c && (r._d = !1), ks(e, r()), r._c && (r._d = !0));
      return;
    } else {
      n = 32;
      const r = t._;
      !r && !Qo(t)
        ? (t._ctx = be)
        : r === 3 &&
          be &&
          (be.slots._ === 1 ? (t._ = 1) : ((t._ = 2), (e.patchFlag |= 1024)));
    }
  else
    K(t)
      ? ((t = { default: t, _ctx: be }), (n = 32))
      : ((t = String(t)), s & 64 ? ((n = 16), (t = [wc(t)])) : (n = 8));
  ((e.children = t), (e.shapeFlag |= n));
}
function Cc(...e) {
  const t = {};
  for (let n = 0; n < e.length; n++) {
    const s = e[n];
    for (const r in s)
      if (r === "class")
        t.class !== s.class && (t.class = Ts([t.class, s.class]));
      else if (r === "style") t.style = As([t.style, s.style]);
      else if (In(r)) {
        const o = t[r],
          i = s[r];
        i &&
          o !== i &&
          !(H(o) && o.includes(i)) &&
          (t[r] = o ? [].concat(o, i) : i);
      } else r !== "" && (t[r] = s[r]);
  }
  return t;
}
function Be(e, t, n, s = null) {
  Fe(e, t, 7, [n, s]);
}
const Rc = Go();
let Pc = 0;
function Ac(e, t, n) {
  const s = e.type,
    r = (t ? t.appContext : e.appContext) || Rc,
    o = {
      uid: Pc++,
      vnode: e,
      type: s,
      parent: t,
      appContext: r,
      root: null,
      next: null,
      subTree: null,
      effect: null,
      update: null,
      job: null,
      scope: new io(!0),
      render: null,
      proxy: null,
      exposed: null,
      exposeProxy: null,
      withProxy: null,
      provides: t ? t.provides : Object.create(r.provides),
      ids: t ? t.ids : ["", 0, 0],
      accessCache: null,
      renderCache: [],
      components: null,
      directives: null,
      propsOptions: Xo(s, r),
      emitsOptions: li(s, r),
      emit: null,
      emitted: null,
      propsDefaults: oe,
      inheritAttrs: s.inheritAttrs,
      ctx: oe,
      data: oe,
      props: oe,
      attrs: oe,
      slots: oe,
      refs: oe,
      setupState: oe,
      setupContext: null,
      suspense: n,
      suspenseId: n ? n.pendingId : 0,
      asyncDep: null,
      asyncResolved: !1,
      isMounted: !1,
      isUnmounted: !1,
      isDeactivated: !1,
      bc: null,
      c: null,
      bm: null,
      m: null,
      bu: null,
      u: null,
      um: null,
      bum: null,
      da: null,
      a: null,
      rtg: null,
      rtc: null,
      ec: null,
      sp: null,
    };
  return (
    (o.ctx = { _: o }),
    (o.root = t ? t.root : o),
    (o.emit = gc.bind(null, o)),
    e.ce && e.ce(o),
    o
  );
}
let de = null;
const Tc = () => de || be;
let On, vs;
{
  const e = Fn(),
    t = (n, s) => {
      let r;
      return (
        (r = e[n]) || (r = e[n] = []),
        r.push(s),
        (o) => {
          r.length > 1 ? r.forEach((i) => i(o)) : r[0](o);
        }
      );
    };
  ((On = t("__VUE_INSTANCE_SETTERS__", (n) => (de = n))),
    (vs = t("__VUE_SSR_SETTERS__", (n) => (rn = n))));
}
const an = (e) => {
    const t = de;
    return (
      On(e),
      e.scope.on(),
      () => {
        (e.scope.off(), On(t));
      }
    );
  },
  ur = () => {
    (de && de.scope.off(), On(null));
  };
function pi(e) {
  return e.vnode.shapeFlag & 4;
}
let rn = !1;
function Oc(e, t = !1, n = !1) {
  t && vs(t);
  const { props: s, children: r } = e.vnode,
    o = pi(e);
  (tc(e, s, o, t), oc(e, r, n));
  const i = o ? Ic(e, t) : void 0;
  return (t && vs(!1), i);
}
function Ic(e, t) {
  const n = e.type;
  ((e.accessCache = Object.create(null)), (e.proxy = new Proxy(e.ctx, ql)));
  const { setup: s } = n;
  if (s) {
    ht();
    const r = (e.setupContext = s.length > 1 ? Lc(e) : null),
      o = an(e),
      i = un(s, e, 0, [e.props, r]),
      l = Zr(i);
    if ((pt(), o(), (l || e.sp) && !qt(e) && Vo(e), l)) {
      if ((i.then(ur, ur), t))
        return i
          .then((c) => {
            ar(e, c);
          })
          .catch((c) => {
            Dn(c, e, 0);
          });
      e.asyncDep = i;
    } else ar(e, i);
  } else gi(e);
}
function ar(e, t, n) {
  (K(t)
    ? e.type.__ssrInlineRender
      ? (e.ssrRender = t)
      : (e.render = t)
    : ce(t) && (e.setupState = Po(t)),
    gi(e));
}
function gi(e, t, n) {
  const s = e.type;
  e.render || (e.render = s.render || We);
  {
    const r = an(e);
    ht();
    try {
      Gl(e);
    } finally {
      (pt(), r());
    }
  }
}
const Mc = {
  get(e, t) {
    return (pe(e, "get", ""), e[t]);
  },
};
function Lc(e) {
  const t = (n) => {
    e.exposed = n || {};
  };
  return {
    attrs: new Proxy(e.attrs, Mc),
    slots: e.slots,
    emit: e.emit,
    expose: t,
  };
}
function kn(e) {
  return e.exposed
    ? e.exposeProxy ||
        (e.exposeProxy = new Proxy(Po(Ds(e.exposed)), {
          get(t, n) {
            if (n in t) return t[n];
            if (n in Gt) return Gt[n](e);
          },
          has(t, n) {
            return n in t || n in Gt;
          },
        }))
    : e.proxy;
}
function Nc(e, t = !0) {
  return K(e) ? e.displayName || e.name : e.name || (t && e.__name);
}
function Fc(e) {
  return K(e) && "__vccOpts" in e;
}
const Ie = (e, t) => Sl(e, t, rn);
function Us(e, t, n) {
  const s = arguments.length;
  return s === 2
    ? ce(t) && !H(t)
      ? Tn(t)
        ? we(e, null, [t])
        : we(e, t)
      : we(e, null, t)
    : (s > 3
        ? (n = Array.prototype.slice.call(arguments, 2))
        : s === 3 && Tn(n) && (n = [n]),
      we(e, t, n));
}
const $c = "3.5.13";
/**
 * @vue/runtime-dom v3.5.13
 * (c) 2018-present Yuxi (Evan) You and Vue contributors
 * @license MIT
 **/ let ys;
const dr = typeof window < "u" && window.trustedTypes;
if (dr)
  try {
    ys = dr.createPolicy("vue", { createHTML: (e) => e });
  } catch {}
const mi = ys ? (e) => ys.createHTML(e) : (e) => e,
  Dc = "http://www.w3.org/2000/svg",
  jc = "http://www.w3.org/1998/Math/MathML",
  Ye = typeof document < "u" ? document : null,
  hr = Ye && Ye.createElement("template"),
  Hc = {
    insert: (e, t, n) => {
      t.insertBefore(e, n || null);
    },
    remove: (e) => {
      const t = e.parentNode;
      t && t.removeChild(e);
    },
    createElement: (e, t, n, s) => {
      const r =
        t === "svg"
          ? Ye.createElementNS(Dc, e)
          : t === "mathml"
            ? Ye.createElementNS(jc, e)
            : n
              ? Ye.createElement(e, { is: n })
              : Ye.createElement(e);
      return (
        e === "select" &&
          s &&
          s.multiple != null &&
          r.setAttribute("multiple", s.multiple),
        r
      );
    },
    createText: (e) => Ye.createTextNode(e),
    createComment: (e) => Ye.createComment(e),
    setText: (e, t) => {
      e.nodeValue = t;
    },
    setElementText: (e, t) => {
      e.textContent = t;
    },
    parentNode: (e) => e.parentNode,
    nextSibling: (e) => e.nextSibling,
    querySelector: (e) => Ye.querySelector(e),
    setScopeId(e, t) {
      e.setAttribute(t, "");
    },
    insertStaticContent(e, t, n, s, r, o) {
      const i = n ? n.previousSibling : t.lastChild;
      if (r && (r === o || r.nextSibling))
        for (
          ;
          t.insertBefore(r.cloneNode(!0), n),
            !(r === o || !(r = r.nextSibling));
        );
      else {
        hr.innerHTML = mi(
          s === "svg"
            ? `<svg>${e}</svg>`
            : s === "mathml"
              ? `<math>${e}</math>`
              : e,
        );
        const l = hr.content;
        if (s === "svg" || s === "mathml") {
          const c = l.firstChild;
          for (; c.firstChild;) l.appendChild(c.firstChild);
          l.removeChild(c);
        }
        t.insertBefore(l, n);
      }
      return [
        i ? i.nextSibling : t.firstChild,
        n ? n.previousSibling : t.lastChild,
      ];
    },
  },
  nt = "transition",
  Vt = "animation",
  on = Symbol("_vtc"),
  vi = {
    name: String,
    type: String,
    css: { type: Boolean, default: !0 },
    duration: [String, Number, Object],
    enterFromClass: String,
    enterActiveClass: String,
    enterToClass: String,
    appearFromClass: String,
    appearActiveClass: String,
    appearToClass: String,
    leaveFromClass: String,
    leaveActiveClass: String,
    leaveToClass: String,
  },
  Vc = he({}, No, vi),
  Bc = (e) => ((e.displayName = "Transition"), (e.props = Vc), e),
  Hu = Bc((e, { slots: t }) => Us(Il, kc(e), t)),
  vt = (e, t = []) => {
    H(e) ? e.forEach((n) => n(...t)) : e && e(...t);
  },
  pr = (e) => (e ? (H(e) ? e.some((t) => t.length > 1) : e.length > 1) : !1);
function kc(e) {
  const t = {};
  for (const O in e) O in vi || (t[O] = e[O]);
  if (e.css === !1) return t;
  const {
      name: n = "v",
      type: s,
      duration: r,
      enterFromClass: o = `${n}-enter-from`,
      enterActiveClass: i = `${n}-enter-active`,
      enterToClass: l = `${n}-enter-to`,
      appearFromClass: c = o,
      appearActiveClass: d = i,
      appearToClass: f = l,
      leaveFromClass: a = `${n}-leave-from`,
      leaveActiveClass: p = `${n}-leave-active`,
      leaveToClass: m = `${n}-leave-to`,
    } = e,
    E = Uc(r),
    P = E && E[0],
    V = E && E[1],
    {
      onBeforeEnter: F,
      onEnter: L,
      onEnterCancelled: N,
      onLeave: M,
      onLeaveCancelled: B,
      onBeforeAppear: ne = F,
      onAppear: G = L,
      onAppearCancelled: W = N,
    } = t,
    A = (O, z, ae, me) => {
      ((O._enterCancelled = me),
        yt(O, z ? f : l),
        yt(O, z ? d : i),
        ae && ae());
    },
    U = (O, z) => {
      ((O._isLeaving = !1), yt(O, a), yt(O, m), yt(O, p), z && z());
    },
    Q = (O) => (z, ae) => {
      const me = O ? G : L,
        se = () => A(z, O, ae);
      (vt(me, [z, se]),
        gr(() => {
          (yt(z, O ? c : o), Je(z, O ? f : l), pr(me) || mr(z, s, P, se));
        }));
    };
  return he(t, {
    onBeforeEnter(O) {
      (vt(F, [O]), Je(O, o), Je(O, i));
    },
    onBeforeAppear(O) {
      (vt(ne, [O]), Je(O, c), Je(O, d));
    },
    onEnter: Q(!1),
    onAppear: Q(!0),
    onLeave(O, z) {
      O._isLeaving = !0;
      const ae = () => U(O, z);
      (Je(O, a),
        O._enterCancelled ? (Je(O, p), _r()) : (_r(), Je(O, p)),
        gr(() => {
          O._isLeaving && (yt(O, a), Je(O, m), pr(M) || mr(O, s, V, ae));
        }),
        vt(M, [O, ae]));
    },
    onEnterCancelled(O) {
      (A(O, !1, void 0, !0), vt(N, [O]));
    },
    onAppearCancelled(O) {
      (A(O, !0, void 0, !0), vt(W, [O]));
    },
    onLeaveCancelled(O) {
      (U(O), vt(B, [O]));
    },
  });
}
function Uc(e) {
  if (e == null) return null;
  if (ce(e)) return [Zn(e.enter), Zn(e.leave)];
  {
    const t = Zn(e);
    return [t, t];
  }
}
function Zn(e) {
  return Vi(e);
}
function Je(e, t) {
  (t.split(/\s+/).forEach((n) => n && e.classList.add(n)),
    (e[on] || (e[on] = new Set())).add(t));
}
function yt(e, t) {
  t.split(/\s+/).forEach((s) => s && e.classList.remove(s));
  const n = e[on];
  n && (n.delete(t), n.size || (e[on] = void 0));
}
function gr(e) {
  requestAnimationFrame(() => {
    requestAnimationFrame(e);
  });
}
let Kc = 0;
function mr(e, t, n, s) {
  const r = (e._endId = ++Kc),
    o = () => {
      r === e._endId && s();
    };
  if (n != null) return setTimeout(o, n);
  const { type: i, timeout: l, propCount: c } = Wc(e, t);
  if (!i) return s();
  const d = i + "end";
  let f = 0;
  const a = () => {
      (e.removeEventListener(d, p), o());
    },
    p = (m) => {
      m.target === e && ++f >= c && a();
    };
  (setTimeout(() => {
    f < c && a();
  }, l + 1),
    e.addEventListener(d, p));
}
function Wc(e, t) {
  const n = window.getComputedStyle(e),
    s = (E) => (n[E] || "").split(", "),
    r = s(`${nt}Delay`),
    o = s(`${nt}Duration`),
    i = vr(r, o),
    l = s(`${Vt}Delay`),
    c = s(`${Vt}Duration`),
    d = vr(l, c);
  let f = null,
    a = 0,
    p = 0;
  t === nt
    ? i > 0 && ((f = nt), (a = i), (p = o.length))
    : t === Vt
      ? d > 0 && ((f = Vt), (a = d), (p = c.length))
      : ((a = Math.max(i, d)),
        (f = a > 0 ? (i > d ? nt : Vt) : null),
        (p = f ? (f === nt ? o.length : c.length) : 0));
  const m =
    f === nt && /\b(transform|all)(,|$)/.test(s(`${nt}Property`).toString());
  return { type: f, timeout: a, propCount: p, hasTransform: m };
}
function vr(e, t) {
  for (; e.length < t.length;) e = e.concat(e);
  return Math.max(...t.map((n, s) => yr(n) + yr(e[s])));
}
function yr(e) {
  return e === "auto" ? 0 : Number(e.slice(0, -1).replace(",", ".")) * 1e3;
}
function _r() {
  return document.body.offsetHeight;
}
function qc(e, t, n) {
  const s = e[on];
  (s && (t = (t ? [t, ...s] : [...s]).join(" ")),
    t == null
      ? e.removeAttribute("class")
      : n
        ? e.setAttribute("class", t)
        : (e.className = t));
}
const br = Symbol("_vod"),
  Gc = Symbol("_vsh"),
  zc = Symbol(""),
  Jc = /(^|;)\s*display\s*:/;
function Qc(e, t, n) {
  const s = e.style,
    r = ue(n);
  let o = !1;
  if (n && !r) {
    if (t)
      if (ue(t))
        for (const i of t.split(";")) {
          const l = i.slice(0, i.indexOf(":")).trim();
          n[l] == null && En(s, l, "");
        }
      else for (const i in t) n[i] == null && En(s, i, "");
    for (const i in n) (i === "display" && (o = !0), En(s, i, n[i]));
  } else if (r) {
    if (t !== n) {
      const i = s[zc];
      (i && (n += ";" + i), (s.cssText = n), (o = Jc.test(n)));
    }
  } else t && e.removeAttribute("style");
  br in e && ((e[br] = o ? s.display : ""), e[Gc] && (s.display = "none"));
}
const Sr = /\s*!important$/;
function En(e, t, n) {
  if (H(n)) n.forEach((s) => En(e, t, s));
  else if ((n == null && (n = ""), t.startsWith("--"))) e.setProperty(t, n);
  else {
    const s = Yc(e, t);
    Sr.test(n)
      ? e.setProperty(wt(s), n.replace(Sr, ""), "important")
      : (e[s] = n);
  }
}
const Er = ["Webkit", "Moz", "ms"],
  es = {};
function Yc(e, t) {
  const n = es[t];
  if (n) return n;
  let s = Le(t);
  if (s !== "filter" && s in e) return (es[t] = s);
  s = Nn(s);
  for (let r = 0; r < Er.length; r++) {
    const o = Er[r] + s;
    if (o in e) return (es[t] = o);
  }
  return t;
}
const xr = "http://www.w3.org/1999/xlink";
function wr(e, t, n, s, r, o = qi(t)) {
  s && t.startsWith("xlink:")
    ? n == null
      ? e.removeAttributeNS(xr, t.slice(6, t.length))
      : e.setAttributeNS(xr, t, n)
    : n == null || (o && !so(n))
      ? e.removeAttribute(t)
      : e.setAttribute(t, o ? "" : dt(n) ? String(n) : n);
}
function Cr(e, t, n, s, r) {
  if (t === "innerHTML" || t === "textContent") {
    n != null && (e[t] = t === "innerHTML" ? mi(n) : n);
    return;
  }
  const o = e.tagName;
  if (t === "value" && o !== "PROGRESS" && !o.includes("-")) {
    const l = o === "OPTION" ? e.getAttribute("value") || "" : e.value,
      c = n == null ? (e.type === "checkbox" ? "on" : "") : String(n);
    ((l !== c || !("_value" in e)) && (e.value = c),
      n == null && e.removeAttribute(t),
      (e._value = n));
    return;
  }
  let i = !1;
  if (n === "" || n == null) {
    const l = typeof e[t];
    l === "boolean"
      ? (n = so(n))
      : n == null && l === "string"
        ? ((n = ""), (i = !0))
        : l === "number" && ((n = 0), (i = !0));
  }
  try {
    e[t] = n;
  } catch {}
  i && e.removeAttribute(r || t);
}
function Ot(e, t, n, s) {
  e.addEventListener(t, n, s);
}
function Xc(e, t, n, s) {
  e.removeEventListener(t, n, s);
}
const Rr = Symbol("_vei");
function Zc(e, t, n, s, r = null) {
  const o = e[Rr] || (e[Rr] = {}),
    i = o[t];
  if (s && i) i.value = s;
  else {
    const [l, c] = ef(t);
    if (s) {
      const d = (o[t] = sf(s, r));
      Ot(e, l, d, c);
    } else i && (Xc(e, l, i, c), (o[t] = void 0));
  }
}
const Pr = /(?:Once|Passive|Capture)$/;
function ef(e) {
  let t;
  if (Pr.test(e)) {
    t = {};
    let s;
    for (; (s = e.match(Pr));)
      ((e = e.slice(0, e.length - s[0].length)), (t[s[0].toLowerCase()] = !0));
  }
  return [e[2] === ":" ? e.slice(3) : wt(e.slice(2)), t];
}
let ts = 0;
const tf = Promise.resolve(),
  nf = () => ts || (tf.then(() => (ts = 0)), (ts = Date.now()));
function sf(e, t) {
  const n = (s) => {
    if (!s._vts) s._vts = Date.now();
    else if (s._vts <= n.attached) return;
    Fe(rf(s, n.value), t, 5, [s]);
  };
  return ((n.value = e), (n.attached = nf()), n);
}
function rf(e, t) {
  if (H(t)) {
    const n = e.stopImmediatePropagation;
    return (
      (e.stopImmediatePropagation = () => {
        (n.call(e), (e._stopped = !0));
      }),
      t.map((s) => (r) => !r._stopped && s && s(r))
    );
  } else return t;
}
const Ar = (e) =>
    e.charCodeAt(0) === 111 &&
    e.charCodeAt(1) === 110 &&
    e.charCodeAt(2) > 96 &&
    e.charCodeAt(2) < 123,
  of = (e, t, n, s, r, o) => {
    const i = r === "svg";
    t === "class"
      ? qc(e, s, i)
      : t === "style"
        ? Qc(e, n, s)
        : In(t)
          ? Cs(t) || Zc(e, t, n, s, o)
          : (
                t[0] === "."
                  ? ((t = t.slice(1)), !0)
                  : t[0] === "^"
                    ? ((t = t.slice(1)), !1)
                    : lf(e, t, s, i)
              )
            ? (Cr(e, t, s),
              !e.tagName.includes("-") &&
                (t === "value" || t === "checked" || t === "selected") &&
                wr(e, t, s, i, o, t !== "value"))
            : e._isVueCE && (/[A-Z]/.test(t) || !ue(s))
              ? Cr(e, Le(t), s, o, t)
              : (t === "true-value"
                  ? (e._trueValue = s)
                  : t === "false-value" && (e._falseValue = s),
                wr(e, t, s, i));
  };
function lf(e, t, n, s) {
  if (s)
    return !!(
      t === "innerHTML" ||
      t === "textContent" ||
      (t in e && Ar(t) && K(n))
    );
  if (
    t === "spellcheck" ||
    t === "draggable" ||
    t === "translate" ||
    t === "form" ||
    (t === "list" && e.tagName === "INPUT") ||
    (t === "type" && e.tagName === "TEXTAREA")
  )
    return !1;
  if (t === "width" || t === "height") {
    const r = e.tagName;
    if (r === "IMG" || r === "VIDEO" || r === "CANVAS" || r === "SOURCE")
      return !1;
  }
  return Ar(t) && ue(n) ? !1 : t in e;
}
const Tr = (e) => {
  const t = e.props["onUpdate:modelValue"] || !1;
  return H(t) ? (n) => yn(t, n) : t;
};
function cf(e) {
  e.target.composing = !0;
}
function Or(e) {
  const t = e.target;
  t.composing && ((t.composing = !1), t.dispatchEvent(new Event("input")));
}
const ns = Symbol("_assign"),
  Vu = {
    created(e, { modifiers: { lazy: t, trim: n, number: s } }, r) {
      e[ns] = Tr(r);
      const o = s || (r.props && r.props.type === "number");
      (Ot(e, t ? "change" : "input", (i) => {
        if (i.target.composing) return;
        let l = e.value;
        (n && (l = l.trim()), o && (l = ls(l)), e[ns](l));
      }),
        n &&
          Ot(e, "change", () => {
            e.value = e.value.trim();
          }),
        t ||
          (Ot(e, "compositionstart", cf),
          Ot(e, "compositionend", Or),
          Ot(e, "change", Or)));
    },
    mounted(e, { value: t }) {
      e.value = t ?? "";
    },
    beforeUpdate(
      e,
      { value: t, oldValue: n, modifiers: { lazy: s, trim: r, number: o } },
      i,
    ) {
      if (((e[ns] = Tr(i)), e.composing)) return;
      const l =
          (o || e.type === "number") && !/^0\d/.test(e.value)
            ? ls(e.value)
            : e.value,
        c = t ?? "";
      l !== c &&
        ((document.activeElement === e &&
          e.type !== "range" &&
          ((s && t === n) || (r && e.value.trim() === c))) ||
          (e.value = c));
    },
  },
  ff = ["ctrl", "shift", "alt", "meta"],
  uf = {
    stop: (e) => e.stopPropagation(),
    prevent: (e) => e.preventDefault(),
    self: (e) => e.target !== e.currentTarget,
    ctrl: (e) => !e.ctrlKey,
    shift: (e) => !e.shiftKey,
    alt: (e) => !e.altKey,
    meta: (e) => !e.metaKey,
    left: (e) => "button" in e && e.button !== 0,
    middle: (e) => "button" in e && e.button !== 1,
    right: (e) => "button" in e && e.button !== 2,
    exact: (e, t) => ff.some((n) => e[`${n}Key`] && !t.includes(n)),
  },
  Bu = (e, t) => {
    const n = e._withMods || (e._withMods = {}),
      s = t.join(".");
    return (
      n[s] ||
      (n[s] = (r, ...o) => {
        for (let i = 0; i < t.length; i++) {
          const l = uf[t[i]];
          if (l && l(r, t)) return;
        }
        return e(r, ...o);
      })
    );
  },
  af = he({ patchProp: of }, Hc);
let Ir;
function df() {
  return Ir || (Ir = lc(af));
}
const hf = (...e) => {
  const t = df().createApp(...e),
    { mount: n } = t;
  return (
    (t.mount = (s) => {
      const r = gf(s);
      if (!r) return;
      const o = t._component;
      (!K(o) && !o.render && !o.template && (o.template = r.innerHTML),
        r.nodeType === 1 && (r.textContent = ""));
      const i = n(r, !1, pf(r));
      return (
        r instanceof Element &&
          (r.removeAttribute("v-cloak"), r.setAttribute("data-v-app", "")),
        i
      );
    }),
    t
  );
};
function pf(e) {
  if (e instanceof SVGElement) return "svg";
  if (typeof MathMLElement == "function" && e instanceof MathMLElement)
    return "mathml";
}
function gf(e) {
  return ue(e) ? document.querySelector(e) : e;
}
var mf = !1;
/*!
 * pinia v2.3.0
 * (c) 2024 Eduardo San Martin Morote
 * @license MIT
 */ let yi;
const Un = (e) => (yi = e),
  _i = Symbol();
function _s(e) {
  return (
    e &&
    typeof e == "object" &&
    Object.prototype.toString.call(e) === "[object Object]" &&
    typeof e.toJSON != "function"
  );
}
var Qt;
(function (e) {
  ((e.direct = "direct"),
    (e.patchObject = "patch object"),
    (e.patchFunction = "patch function"));
})(Qt || (Qt = {}));
function vf() {
  const e = lo(!0),
    t = e.run(() => js({}));
  let n = [],
    s = [];
  const r = Ds({
    install(o) {
      (Un(r),
        (r._a = o),
        o.provide(_i, r),
        (o.config.globalProperties.$pinia = r),
        s.forEach((i) => n.push(i)),
        (s = []));
    },
    use(o) {
      return (!this._a && !mf ? s.push(o) : n.push(o), this);
    },
    _p: n,
    _a: null,
    _e: e,
    _s: new Map(),
    state: t,
  });
  return r;
}
const bi = () => {};
function Mr(e, t, n, s = bi) {
  e.push(t);
  const r = () => {
    const o = e.indexOf(t);
    o > -1 && (e.splice(o, 1), s());
  };
  return (!n && co() && zi(r), r);
}
function At(e, ...t) {
  e.slice().forEach((n) => {
    n(...t);
  });
}
const yf = (e) => e(),
  Lr = Symbol(),
  ss = Symbol();
function bs(e, t) {
  e instanceof Map && t instanceof Map
    ? t.forEach((n, s) => e.set(s, n))
    : e instanceof Set && t instanceof Set && t.forEach(e.add, e);
  for (const n in t) {
    if (!t.hasOwnProperty(n)) continue;
    const s = t[n],
      r = e[n];
    _s(r) && _s(s) && e.hasOwnProperty(n) && !fe(s) && !ut(s)
      ? (e[n] = bs(r, s))
      : (e[n] = s);
  }
  return e;
}
const _f = Symbol();
function bf(e) {
  return !_s(e) || !e.hasOwnProperty(_f);
}
const { assign: rt } = Object;
function Sf(e) {
  return !!(fe(e) && e.effect);
}
function Ef(e, t, n, s) {
  const { state: r, actions: o, getters: i } = t,
    l = n.state.value[e];
  let c;
  function d() {
    l || (n.state.value[e] = r ? r() : {});
    const f = vl(n.state.value[e]);
    return rt(
      f,
      o,
      Object.keys(i || {}).reduce(
        (a, p) => (
          (a[p] = Ds(
            Ie(() => {
              Un(n);
              const m = n._s.get(e);
              return i[p].call(m, m);
            }),
          )),
          a
        ),
        {},
      ),
    );
  }
  return ((c = Si(e, d, t, n, s, !0)), c);
}
function Si(e, t, n = {}, s, r, o) {
  let i;
  const l = rt({ actions: {} }, n),
    c = { deep: !0 };
  let d,
    f,
    a = [],
    p = [],
    m;
  const E = s.state.value[e];
  (!o && !E && (s.state.value[e] = {}), js({}));
  let P;
  function V(W) {
    let A;
    ((d = f = !1),
      typeof W == "function"
        ? (W(s.state.value[e]),
          (A = { type: Qt.patchFunction, storeId: e, events: m }))
        : (bs(s.state.value[e], W),
          (A = { type: Qt.patchObject, payload: W, storeId: e, events: m })));
    const U = (P = Symbol());
    (Hs().then(() => {
      P === U && (d = !0);
    }),
      (f = !0),
      At(a, A, s.state.value[e]));
  }
  const F = o
    ? function () {
        const { state: A } = n,
          U = A ? A() : {};
        this.$patch((Q) => {
          rt(Q, U);
        });
      }
    : bi;
  function L() {
    (i.stop(), (a = []), (p = []), s._s.delete(e));
  }
  const N = (W, A = "") => {
      if (Lr in W) return ((W[ss] = A), W);
      const U = function () {
        Un(s);
        const Q = Array.from(arguments),
          O = [],
          z = [];
        function ae(q) {
          O.push(q);
        }
        function me(q) {
          z.push(q);
        }
        At(p, { args: Q, name: U[ss], store: B, after: ae, onError: me });
        let se;
        try {
          se = W.apply(this && this.$id === e ? this : B, Q);
        } catch (q) {
          throw (At(z, q), q);
        }
        return se instanceof Promise
          ? se
              .then((q) => (At(O, q), q))
              .catch((q) => (At(z, q), Promise.reject(q)))
          : (At(O, se), se);
      };
      return ((U[Lr] = !0), (U[ss] = A), U);
    },
    M = {
      _p: s,
      $id: e,
      $onAction: Mr.bind(null, p),
      $patch: V,
      $reset: F,
      $subscribe(W, A = {}) {
        const U = Mr(a, W, A.detached, () => Q()),
          Q = i.run(() =>
            zt(
              () => s.state.value[e],
              (O) => {
                (A.flush === "sync" ? f : d) &&
                  W({ storeId: e, type: Qt.direct, events: m }, O);
              },
              rt({}, c, A),
            ),
          );
        return U;
      },
      $dispose: L,
    },
    B = fn(M);
  s._s.set(e, B);
  const G = ((s._a && s._a.runWithContext) || yf)(() =>
    s._e.run(() => (i = lo()).run(() => t({ action: N }))),
  );
  for (const W in G) {
    const A = G[W];
    if ((fe(A) && !Sf(A)) || ut(A))
      o ||
        (E && bf(A) && (fe(A) ? (A.value = E[W]) : bs(A, E[W])),
        (s.state.value[e][W] = A));
    else if (typeof A == "function") {
      const U = N(A, W);
      ((G[W] = U), (l.actions[W] = A));
    }
  }
  return (
    rt(B, G),
    rt(Y(B), G),
    Object.defineProperty(B, "$state", {
      get: () => s.state.value[e],
      set: (W) => {
        V((A) => {
          rt(A, W);
        });
      },
    }),
    s._p.forEach((W) => {
      rt(
        B,
        i.run(() => W({ store: B, app: s._a, pinia: s, options: l })),
      );
    }),
    E && o && n.hydrate && n.hydrate(B.$state, E),
    (d = !0),
    (f = !0),
    B
  );
}
/*! #__NO_SIDE_EFFECTS__ */ function ku(e, t, n) {
  let s, r;
  const o = typeof t == "function";
  ((s = e), (r = o ? n : t));
  function i(l, c) {
    const d = ec();
    return (
      (l = l || (d ? qe(_i, null) : null)),
      l && Un(l),
      (l = yi),
      l._s.has(s) || (o ? Si(s, t, r, l) : Ef(s, r, l)),
      l._s.get(s)
    );
  }
  return ((i.$id = s), i);
}
const xf = (e, t) => {
    const n = e.__vccOpts || e;
    for (const [s, r] of t) n[s] = r;
    return n;
  },
  wf = {};
function Cf(e, t) {
  const n = Ul("RouterView");
  return (fi(), ai(n));
}
const Rf = xf(wf, [["render", Cf]]),
  Pf = "modulepreload",
  Af = function (e) {
    return "/" + e;
  },
  Nr = {},
  vn = function (t, n, s) {
    let r = Promise.resolve();
    if (n && n.length > 0) {
      document.getElementsByTagName("link");
      const i = document.querySelector("meta[property=csp-nonce]"),
        l =
          (i == null ? void 0 : i.nonce) ||
          (i == null ? void 0 : i.getAttribute("nonce"));
      r = Promise.allSettled(
        n.map((c) => {
          if (((c = Af(c)), c in Nr)) return;
          Nr[c] = !0;
          const d = c.endsWith(".css"),
            f = d ? '[rel="stylesheet"]' : "";
          if (document.querySelector(`link[href="${c}"]${f}`)) return;
          const a = document.createElement("link");
          if (
            ((a.rel = d ? "stylesheet" : Pf),
            d || (a.as = "script"),
            (a.crossOrigin = ""),
            (a.href = c),
            l && a.setAttribute("nonce", l),
            document.head.appendChild(a),
            d)
          )
            return new Promise((p, m) => {
              (a.addEventListener("load", p),
                a.addEventListener("error", () =>
                  m(new Error(`Unable to preload CSS for ${c}`)),
                ));
            });
        }),
      );
    }
    function o(i) {
      const l = new Event("vite:preloadError", { cancelable: !0 });
      if (((l.payload = i), window.dispatchEvent(l), !l.defaultPrevented))
        throw i;
    }
    return r.then((i) => {
      for (const l of i || []) l.status === "rejected" && o(l.reason);
      return t().catch(o);
    });
  };
/*!
 * vue-router v4.5.0
 * (c) 2024 Eduardo San Martin Morote
 * @license MIT
 */ const It = typeof document < "u";
function Ei(e) {
  return (
    typeof e == "object" ||
    "displayName" in e ||
    "props" in e ||
    "__vccOpts" in e
  );
}
function Tf(e) {
  return (
    e.__esModule ||
    e[Symbol.toStringTag] === "Module" ||
    (e.default && Ei(e.default))
  );
}
const Z = Object.assign;
function rs(e, t) {
  const n = {};
  for (const s in t) {
    const r = t[s];
    n[s] = $e(r) ? r.map(e) : e(r);
  }
  return n;
}
const Yt = () => {},
  $e = Array.isArray,
  xi = /#/g,
  Of = /&/g,
  If = /\//g,
  Mf = /=/g,
  Lf = /\?/g,
  wi = /\+/g,
  Nf = /%5B/g,
  Ff = /%5D/g,
  Ci = /%5E/g,
  $f = /%60/g,
  Ri = /%7B/g,
  Df = /%7C/g,
  Pi = /%7D/g,
  jf = /%20/g;
function Ks(e) {
  return encodeURI("" + e)
    .replace(Df, "|")
    .replace(Nf, "[")
    .replace(Ff, "]");
}
function Hf(e) {
  return Ks(e).replace(Ri, "{").replace(Pi, "}").replace(Ci, "^");
}
function Ss(e) {
  return Ks(e)
    .replace(wi, "%2B")
    .replace(jf, "+")
    .replace(xi, "%23")
    .replace(Of, "%26")
    .replace($f, "`")
    .replace(Ri, "{")
    .replace(Pi, "}")
    .replace(Ci, "^");
}
function Vf(e) {
  return Ss(e).replace(Mf, "%3D");
}
function Bf(e) {
  return Ks(e).replace(xi, "%23").replace(Lf, "%3F");
}
function kf(e) {
  return e == null ? "" : Bf(e).replace(If, "%2F");
}
function ln(e) {
  try {
    return decodeURIComponent("" + e);
  } catch {}
  return "" + e;
}
const Uf = /\/$/,
  Kf = (e) => e.replace(Uf, "");
function os(e, t, n = "/") {
  let s,
    r = {},
    o = "",
    i = "";
  const l = t.indexOf("#");
  let c = t.indexOf("?");
  return (
    l < c && l >= 0 && (c = -1),
    c > -1 &&
      ((s = t.slice(0, c)),
      (o = t.slice(c + 1, l > -1 ? l : t.length)),
      (r = e(o))),
    l > -1 && ((s = s || t.slice(0, l)), (i = t.slice(l, t.length))),
    (s = zf(s ?? t, n)),
    { fullPath: s + (o && "?") + o + i, path: s, query: r, hash: ln(i) }
  );
}
function Wf(e, t) {
  const n = t.query ? e(t.query) : "";
  return t.path + (n && "?") + n + (t.hash || "");
}
function Fr(e, t) {
  return !t || !e.toLowerCase().startsWith(t.toLowerCase())
    ? e
    : e.slice(t.length) || "/";
}
function qf(e, t, n) {
  const s = t.matched.length - 1,
    r = n.matched.length - 1;
  return (
    s > -1 &&
    s === r &&
    $t(t.matched[s], n.matched[r]) &&
    Ai(t.params, n.params) &&
    e(t.query) === e(n.query) &&
    t.hash === n.hash
  );
}
function $t(e, t) {
  return (e.aliasOf || e) === (t.aliasOf || t);
}
function Ai(e, t) {
  if (Object.keys(e).length !== Object.keys(t).length) return !1;
  for (const n in e) if (!Gf(e[n], t[n])) return !1;
  return !0;
}
function Gf(e, t) {
  return $e(e) ? $r(e, t) : $e(t) ? $r(t, e) : e === t;
}
function $r(e, t) {
  return $e(t)
    ? e.length === t.length && e.every((n, s) => n === t[s])
    : e.length === 1 && e[0] === t;
}
function zf(e, t) {
  if (e.startsWith("/")) return e;
  if (!e) return t;
  const n = t.split("/"),
    s = e.split("/"),
    r = s[s.length - 1];
  (r === ".." || r === ".") && s.push("");
  let o = n.length - 1,
    i,
    l;
  for (i = 0; i < s.length; i++)
    if (((l = s[i]), l !== "."))
      if (l === "..") o > 1 && o--;
      else break;
  return n.slice(0, o).join("/") + "/" + s.slice(i).join("/");
}
const st = {
  path: "/",
  name: void 0,
  params: {},
  query: {},
  hash: "",
  fullPath: "/",
  matched: [],
  meta: {},
  redirectedFrom: void 0,
};
var cn;
(function (e) {
  ((e.pop = "pop"), (e.push = "push"));
})(cn || (cn = {}));
var Xt;
(function (e) {
  ((e.back = "back"), (e.forward = "forward"), (e.unknown = ""));
})(Xt || (Xt = {}));
function Jf(e) {
  if (!e)
    if (It) {
      const t = document.querySelector("base");
      ((e = (t && t.getAttribute("href")) || "/"),
        (e = e.replace(/^\w+:\/\/[^\/]+/, "")));
    } else e = "/";
  return (e[0] !== "/" && e[0] !== "#" && (e = "/" + e), Kf(e));
}
const Qf = /^[^#]+#/;
function Yf(e, t) {
  return e.replace(Qf, "#") + t;
}
function Xf(e, t) {
  const n = document.documentElement.getBoundingClientRect(),
    s = e.getBoundingClientRect();
  return {
    behavior: t.behavior,
    left: s.left - n.left - (t.left || 0),
    top: s.top - n.top - (t.top || 0),
  };
}
const Kn = () => ({ left: window.scrollX, top: window.scrollY });
function Zf(e) {
  let t;
  if ("el" in e) {
    const n = e.el,
      s = typeof n == "string" && n.startsWith("#"),
      r =
        typeof n == "string"
          ? s
            ? document.getElementById(n.slice(1))
            : document.querySelector(n)
          : n;
    if (!r) return;
    t = Xf(r, e);
  } else t = e;
  "scrollBehavior" in document.documentElement.style
    ? window.scrollTo(t)
    : window.scrollTo(
        t.left != null ? t.left : window.scrollX,
        t.top != null ? t.top : window.scrollY,
      );
}
function Dr(e, t) {
  return (history.state ? history.state.position - t : -1) + e;
}
const Es = new Map();
function eu(e, t) {
  Es.set(e, t);
}
function tu(e) {
  const t = Es.get(e);
  return (Es.delete(e), t);
}
let nu = () => location.protocol + "//" + location.host;
function Ti(e, t) {
  const { pathname: n, search: s, hash: r } = t,
    o = e.indexOf("#");
  if (o > -1) {
    let l = r.includes(e.slice(o)) ? e.slice(o).length : 1,
      c = r.slice(l);
    return (c[0] !== "/" && (c = "/" + c), Fr(c, ""));
  }
  return Fr(n, e) + s + r;
}
function su(e, t, n, s) {
  let r = [],
    o = [],
    i = null;
  const l = ({ state: p }) => {
    const m = Ti(e, location),
      E = n.value,
      P = t.value;
    let V = 0;
    if (p) {
      if (((n.value = m), (t.value = p), i && i === E)) {
        i = null;
        return;
      }
      V = P ? p.position - P.position : 0;
    } else s(m);
    r.forEach((F) => {
      F(n.value, E, {
        delta: V,
        type: cn.pop,
        direction: V ? (V > 0 ? Xt.forward : Xt.back) : Xt.unknown,
      });
    });
  };
  function c() {
    i = n.value;
  }
  function d(p) {
    r.push(p);
    const m = () => {
      const E = r.indexOf(p);
      E > -1 && r.splice(E, 1);
    };
    return (o.push(m), m);
  }
  function f() {
    const { history: p } = window;
    p.state && p.replaceState(Z({}, p.state, { scroll: Kn() }), "");
  }
  function a() {
    for (const p of o) p();
    ((o = []),
      window.removeEventListener("popstate", l),
      window.removeEventListener("beforeunload", f));
  }
  return (
    window.addEventListener("popstate", l),
    window.addEventListener("beforeunload", f, { passive: !0 }),
    { pauseListeners: c, listen: d, destroy: a }
  );
}
function jr(e, t, n, s = !1, r = !1) {
  return {
    back: e,
    current: t,
    forward: n,
    replaced: s,
    position: window.history.length,
    scroll: r ? Kn() : null,
  };
}
function ru(e) {
  const { history: t, location: n } = window,
    s = { value: Ti(e, n) },
    r = { value: t.state };
  r.value ||
    o(
      s.value,
      {
        back: null,
        current: s.value,
        forward: null,
        position: t.length - 1,
        replaced: !0,
        scroll: null,
      },
      !0,
    );
  function o(c, d, f) {
    const a = e.indexOf("#"),
      p =
        a > -1
          ? (n.host && document.querySelector("base") ? e : e.slice(a)) + c
          : nu() + e + c;
    try {
      (t[f ? "replaceState" : "pushState"](d, "", p), (r.value = d));
    } catch (m) {
      (console.error(m), n[f ? "replace" : "assign"](p));
    }
  }
  function i(c, d) {
    const f = Z({}, t.state, jr(r.value.back, c, r.value.forward, !0), d, {
      position: r.value.position,
    });
    (o(c, f, !0), (s.value = c));
  }
  function l(c, d) {
    const f = Z({}, r.value, t.state, { forward: c, scroll: Kn() });
    o(f.current, f, !0);
    const a = Z({}, jr(s.value, c, null), { position: f.position + 1 }, d);
    (o(c, a, !1), (s.value = c));
  }
  return { location: s, state: r, push: l, replace: i };
}
function ou(e) {
  e = Jf(e);
  const t = ru(e),
    n = su(e, t.state, t.location, t.replace);
  function s(o, i = !0) {
    (i || n.pauseListeners(), history.go(o));
  }
  const r = Z(
    { location: "", base: e, go: s, createHref: Yf.bind(null, e) },
    t,
    n,
  );
  return (
    Object.defineProperty(r, "location", {
      enumerable: !0,
      get: () => t.location.value,
    }),
    Object.defineProperty(r, "state", {
      enumerable: !0,
      get: () => t.state.value,
    }),
    r
  );
}
function iu(e) {
  return typeof e == "string" || (e && typeof e == "object");
}
function Oi(e) {
  return typeof e == "string" || typeof e == "symbol";
}
const Ii = Symbol("");
var Hr;
(function (e) {
  ((e[(e.aborted = 4)] = "aborted"),
    (e[(e.cancelled = 8)] = "cancelled"),
    (e[(e.duplicated = 16)] = "duplicated"));
})(Hr || (Hr = {}));
function Dt(e, t) {
  return Z(new Error(), { type: e, [Ii]: !0 }, t);
}
function Qe(e, t) {
  return e instanceof Error && Ii in e && (t == null || !!(e.type & t));
}
const Vr = "[^/]+?",
  lu = { sensitive: !1, strict: !1, start: !0, end: !0 },
  cu = /[.+*?^${}()[\]/\\]/g;
function fu(e, t) {
  const n = Z({}, lu, t),
    s = [];
  let r = n.start ? "^" : "";
  const o = [];
  for (const d of e) {
    const f = d.length ? [] : [90];
    n.strict && !d.length && (r += "/");
    for (let a = 0; a < d.length; a++) {
      const p = d[a];
      let m = 40 + (n.sensitive ? 0.25 : 0);
      if (p.type === 0)
        (a || (r += "/"), (r += p.value.replace(cu, "\\$&")), (m += 40));
      else if (p.type === 1) {
        const { value: E, repeatable: P, optional: V, regexp: F } = p;
        o.push({ name: E, repeatable: P, optional: V });
        const L = F || Vr;
        if (L !== Vr) {
          m += 10;
          try {
            new RegExp(`(${L})`);
          } catch (M) {
            throw new Error(
              `Invalid custom RegExp for param "${E}" (${L}): ` + M.message,
            );
          }
        }
        let N = P ? `((?:${L})(?:/(?:${L}))*)` : `(${L})`;
        (a || (N = V && d.length < 2 ? `(?:/${N})` : "/" + N),
          V && (N += "?"),
          (r += N),
          (m += 20),
          V && (m += -8),
          P && (m += -20),
          L === ".*" && (m += -50));
      }
      f.push(m);
    }
    s.push(f);
  }
  if (n.strict && n.end) {
    const d = s.length - 1;
    s[d][s[d].length - 1] += 0.7000000000000001;
  }
  (n.strict || (r += "/?"),
    n.end ? (r += "$") : n.strict && !r.endsWith("/") && (r += "(?:/|$)"));
  const i = new RegExp(r, n.sensitive ? "" : "i");
  function l(d) {
    const f = d.match(i),
      a = {};
    if (!f) return null;
    for (let p = 1; p < f.length; p++) {
      const m = f[p] || "",
        E = o[p - 1];
      a[E.name] = m && E.repeatable ? m.split("/") : m;
    }
    return a;
  }
  function c(d) {
    let f = "",
      a = !1;
    for (const p of e) {
      ((!a || !f.endsWith("/")) && (f += "/"), (a = !1));
      for (const m of p)
        if (m.type === 0) f += m.value;
        else if (m.type === 1) {
          const { value: E, repeatable: P, optional: V } = m,
            F = E in d ? d[E] : "";
          if ($e(F) && !P)
            throw new Error(
              `Provided param "${E}" is an array but it is not repeatable (* or + modifiers)`,
            );
          const L = $e(F) ? F.join("/") : F;
          if (!L)
            if (V)
              p.length < 2 &&
                (f.endsWith("/") ? (f = f.slice(0, -1)) : (a = !0));
            else throw new Error(`Missing required param "${E}"`);
          f += L;
        }
    }
    return f || "/";
  }
  return { re: i, score: s, keys: o, parse: l, stringify: c };
}
function uu(e, t) {
  let n = 0;
  for (; n < e.length && n < t.length;) {
    const s = t[n] - e[n];
    if (s) return s;
    n++;
  }
  return e.length < t.length
    ? e.length === 1 && e[0] === 80
      ? -1
      : 1
    : e.length > t.length
      ? t.length === 1 && t[0] === 80
        ? 1
        : -1
      : 0;
}
function Mi(e, t) {
  let n = 0;
  const s = e.score,
    r = t.score;
  for (; n < s.length && n < r.length;) {
    const o = uu(s[n], r[n]);
    if (o) return o;
    n++;
  }
  if (Math.abs(r.length - s.length) === 1) {
    if (Br(s)) return 1;
    if (Br(r)) return -1;
  }
  return r.length - s.length;
}
function Br(e) {
  const t = e[e.length - 1];
  return e.length > 0 && t[t.length - 1] < 0;
}
const au = { type: 0, value: "" },
  du = /[a-zA-Z0-9_]/;
function hu(e) {
  if (!e) return [[]];
  if (e === "/") return [[au]];
  if (!e.startsWith("/")) throw new Error(`Invalid path "${e}"`);
  function t(m) {
    throw new Error(`ERR (${n})/"${d}": ${m}`);
  }
  let n = 0,
    s = n;
  const r = [];
  let o;
  function i() {
    (o && r.push(o), (o = []));
  }
  let l = 0,
    c,
    d = "",
    f = "";
  function a() {
    d &&
      (n === 0
        ? o.push({ type: 0, value: d })
        : n === 1 || n === 2 || n === 3
          ? (o.length > 1 &&
              (c === "*" || c === "+") &&
              t(
                `A repeatable param (${d}) must be alone in its segment. eg: '/:ids+.`,
              ),
            o.push({
              type: 1,
              value: d,
              regexp: f,
              repeatable: c === "*" || c === "+",
              optional: c === "*" || c === "?",
            }))
          : t("Invalid state to consume buffer"),
      (d = ""));
  }
  function p() {
    d += c;
  }
  for (; l < e.length;) {
    if (((c = e[l++]), c === "\\" && n !== 2)) {
      ((s = n), (n = 4));
      continue;
    }
    switch (n) {
      case 0:
        c === "/" ? (d && a(), i()) : c === ":" ? (a(), (n = 1)) : p();
        break;
      case 4:
        (p(), (n = s));
        break;
      case 1:
        c === "("
          ? (n = 2)
          : du.test(c)
            ? p()
            : (a(), (n = 0), c !== "*" && c !== "?" && c !== "+" && l--);
        break;
      case 2:
        c === ")"
          ? f[f.length - 1] == "\\"
            ? (f = f.slice(0, -1) + c)
            : (n = 3)
          : (f += c);
        break;
      case 3:
        (a(), (n = 0), c !== "*" && c !== "?" && c !== "+" && l--, (f = ""));
        break;
      default:
        t("Unknown state");
        break;
    }
  }
  return (
    n === 2 && t(`Unfinished custom RegExp for param "${d}"`),
    a(),
    i(),
    r
  );
}
function pu(e, t, n) {
  const s = fu(hu(e.path), n),
    r = Z(s, { record: e, parent: t, children: [], alias: [] });
  return (t && !r.record.aliasOf == !t.record.aliasOf && t.children.push(r), r);
}
function gu(e, t) {
  const n = [],
    s = new Map();
  t = Wr({ strict: !1, end: !0, sensitive: !1 }, t);
  function r(a) {
    return s.get(a);
  }
  function o(a, p, m) {
    const E = !m,
      P = Ur(a);
    P.aliasOf = m && m.record;
    const V = Wr(t, a),
      F = [P];
    if ("alias" in a) {
      const M = typeof a.alias == "string" ? [a.alias] : a.alias;
      for (const B of M)
        F.push(
          Ur(
            Z({}, P, {
              components: m ? m.record.components : P.components,
              path: B,
              aliasOf: m ? m.record : P,
            }),
          ),
        );
    }
    let L, N;
    for (const M of F) {
      const { path: B } = M;
      if (p && B[0] !== "/") {
        const ne = p.record.path,
          G = ne[ne.length - 1] === "/" ? "" : "/";
        M.path = p.record.path + (B && G + B);
      }
      if (
        ((L = pu(M, p, V)),
        m
          ? m.alias.push(L)
          : ((N = N || L),
            N !== L && N.alias.push(L),
            E && a.name && !Kr(L) && i(a.name)),
        Li(L) && c(L),
        P.children)
      ) {
        const ne = P.children;
        for (let G = 0; G < ne.length; G++) o(ne[G], L, m && m.children[G]);
      }
      m = m || L;
    }
    return N
      ? () => {
          i(N);
        }
      : Yt;
  }
  function i(a) {
    if (Oi(a)) {
      const p = s.get(a);
      p &&
        (s.delete(a),
        n.splice(n.indexOf(p), 1),
        p.children.forEach(i),
        p.alias.forEach(i));
    } else {
      const p = n.indexOf(a);
      p > -1 &&
        (n.splice(p, 1),
        a.record.name && s.delete(a.record.name),
        a.children.forEach(i),
        a.alias.forEach(i));
    }
  }
  function l() {
    return n;
  }
  function c(a) {
    const p = yu(a, n);
    (n.splice(p, 0, a), a.record.name && !Kr(a) && s.set(a.record.name, a));
  }
  function d(a, p) {
    let m,
      E = {},
      P,
      V;
    if ("name" in a && a.name) {
      if (((m = s.get(a.name)), !m)) throw Dt(1, { location: a });
      ((V = m.record.name),
        (E = Z(
          kr(
            p.params,
            m.keys
              .filter((N) => !N.optional)
              .concat(m.parent ? m.parent.keys.filter((N) => N.optional) : [])
              .map((N) => N.name),
          ),
          a.params &&
            kr(
              a.params,
              m.keys.map((N) => N.name),
            ),
        )),
        (P = m.stringify(E)));
    } else if (a.path != null)
      ((P = a.path),
        (m = n.find((N) => N.re.test(P))),
        m && ((E = m.parse(P)), (V = m.record.name)));
    else {
      if (((m = p.name ? s.get(p.name) : n.find((N) => N.re.test(p.path))), !m))
        throw Dt(1, { location: a, currentLocation: p });
      ((V = m.record.name),
        (E = Z({}, p.params, a.params)),
        (P = m.stringify(E)));
    }
    const F = [];
    let L = m;
    for (; L;) (F.unshift(L.record), (L = L.parent));
    return { name: V, path: P, params: E, matched: F, meta: vu(F) };
  }
  e.forEach((a) => o(a));
  function f() {
    ((n.length = 0), s.clear());
  }
  return {
    addRoute: o,
    resolve: d,
    removeRoute: i,
    clearRoutes: f,
    getRoutes: l,
    getRecordMatcher: r,
  };
}
function kr(e, t) {
  const n = {};
  for (const s of t) s in e && (n[s] = e[s]);
  return n;
}
function Ur(e) {
  const t = {
    path: e.path,
    redirect: e.redirect,
    name: e.name,
    meta: e.meta || {},
    aliasOf: e.aliasOf,
    beforeEnter: e.beforeEnter,
    props: mu(e),
    children: e.children || [],
    instances: {},
    leaveGuards: new Set(),
    updateGuards: new Set(),
    enterCallbacks: {},
    components:
      "components" in e
        ? e.components || null
        : e.component && { default: e.component },
  };
  return (Object.defineProperty(t, "mods", { value: {} }), t);
}
function mu(e) {
  const t = {},
    n = e.props || !1;
  if ("component" in e) t.default = n;
  else for (const s in e.components) t[s] = typeof n == "object" ? n[s] : n;
  return t;
}
function Kr(e) {
  for (; e;) {
    if (e.record.aliasOf) return !0;
    e = e.parent;
  }
  return !1;
}
function vu(e) {
  return e.reduce((t, n) => Z(t, n.meta), {});
}
function Wr(e, t) {
  const n = {};
  for (const s in e) n[s] = s in t ? t[s] : e[s];
  return n;
}
function yu(e, t) {
  let n = 0,
    s = t.length;
  for (; n !== s;) {
    const o = (n + s) >> 1;
    Mi(e, t[o]) < 0 ? (s = o) : (n = o + 1);
  }
  const r = _u(e);
  return (r && (s = t.lastIndexOf(r, s - 1)), s);
}
function _u(e) {
  let t = e;
  for (; (t = t.parent);) if (Li(t) && Mi(e, t) === 0) return t;
}
function Li({ record: e }) {
  return !!(
    e.name ||
    (e.components && Object.keys(e.components).length) ||
    e.redirect
  );
}
function bu(e) {
  const t = {};
  if (e === "" || e === "?") return t;
  const s = (e[0] === "?" ? e.slice(1) : e).split("&");
  for (let r = 0; r < s.length; ++r) {
    const o = s[r].replace(wi, " "),
      i = o.indexOf("="),
      l = ln(i < 0 ? o : o.slice(0, i)),
      c = i < 0 ? null : ln(o.slice(i + 1));
    if (l in t) {
      let d = t[l];
      ($e(d) || (d = t[l] = [d]), d.push(c));
    } else t[l] = c;
  }
  return t;
}
function qr(e) {
  let t = "";
  for (let n in e) {
    const s = e[n];
    if (((n = Vf(n)), s == null)) {
      s !== void 0 && (t += (t.length ? "&" : "") + n);
      continue;
    }
    ($e(s) ? s.map((o) => o && Ss(o)) : [s && Ss(s)]).forEach((o) => {
      o !== void 0 &&
        ((t += (t.length ? "&" : "") + n), o != null && (t += "=" + o));
    });
  }
  return t;
}
function Su(e) {
  const t = {};
  for (const n in e) {
    const s = e[n];
    s !== void 0 &&
      (t[n] = $e(s)
        ? s.map((r) => (r == null ? null : "" + r))
        : s == null
          ? s
          : "" + s);
  }
  return t;
}
const Eu = Symbol(""),
  Gr = Symbol(""),
  Ws = Symbol(""),
  Ni = Symbol(""),
  xs = Symbol("");
function Bt() {
  let e = [];
  function t(s) {
    return (
      e.push(s),
      () => {
        const r = e.indexOf(s);
        r > -1 && e.splice(r, 1);
      }
    );
  }
  function n() {
    e = [];
  }
  return { add: t, list: () => e.slice(), reset: n };
}
function ct(e, t, n, s, r, o = (i) => i()) {
  const i = s && (s.enterCallbacks[r] = s.enterCallbacks[r] || []);
  return () =>
    new Promise((l, c) => {
      const d = (p) => {
          p === !1
            ? c(Dt(4, { from: n, to: t }))
            : p instanceof Error
              ? c(p)
              : iu(p)
                ? c(Dt(2, { from: t, to: p }))
                : (i &&
                    s.enterCallbacks[r] === i &&
                    typeof p == "function" &&
                    i.push(p),
                  l());
        },
        f = o(() => e.call(s && s.instances[r], t, n, d));
      let a = Promise.resolve(f);
      (e.length < 3 && (a = a.then(d)), a.catch((p) => c(p)));
    });
}
function is(e, t, n, s, r = (o) => o()) {
  const o = [];
  for (const i of e)
    for (const l in i.components) {
      let c = i.components[l];
      if (!(t !== "beforeRouteEnter" && !i.instances[l]))
        if (Ei(c)) {
          const f = (c.__vccOpts || c)[t];
          f && o.push(ct(f, n, s, i, l, r));
        } else {
          let d = c();
          o.push(() =>
            d.then((f) => {
              if (!f)
                throw new Error(
                  `Couldn't resolve component "${l}" at "${i.path}"`,
                );
              const a = Tf(f) ? f.default : f;
              ((i.mods[l] = f), (i.components[l] = a));
              const m = (a.__vccOpts || a)[t];
              return m && ct(m, n, s, i, l, r)();
            }),
          );
        }
    }
  return o;
}
function zr(e) {
  const t = qe(Ws),
    n = qe(Ni),
    s = Ie(() => {
      const c = Nt(e.to);
      return t.resolve(c);
    }),
    r = Ie(() => {
      const { matched: c } = s.value,
        { length: d } = c,
        f = c[d - 1],
        a = n.matched;
      if (!f || !a.length) return -1;
      const p = a.findIndex($t.bind(null, f));
      if (p > -1) return p;
      const m = Jr(c[d - 2]);
      return d > 1 && Jr(f) === m && a[a.length - 1].path !== m
        ? a.findIndex($t.bind(null, c[d - 2]))
        : p;
    }),
    o = Ie(() => r.value > -1 && Pu(n.params, s.value.params)),
    i = Ie(
      () =>
        r.value > -1 &&
        r.value === n.matched.length - 1 &&
        Ai(n.params, s.value.params),
    );
  function l(c = {}) {
    if (Ru(c)) {
      const d = t[Nt(e.replace) ? "replace" : "push"](Nt(e.to)).catch(Yt);
      return (
        e.viewTransition &&
          typeof document < "u" &&
          "startViewTransition" in document &&
          document.startViewTransition(() => d),
        d
      );
    }
    return Promise.resolve();
  }
  return {
    route: s,
    href: Ie(() => s.value.href),
    isActive: o,
    isExactActive: i,
    navigate: l,
  };
}
function xu(e) {
  return e.length === 1 ? e[0] : e;
}
const wu = Ho({
    name: "RouterLink",
    compatConfig: { MODE: 3 },
    props: {
      to: { type: [String, Object], required: !0 },
      replace: Boolean,
      activeClass: String,
      exactActiveClass: String,
      custom: Boolean,
      ariaCurrentValue: { type: String, default: "page" },
    },
    useLink: zr,
    setup(e, { slots: t }) {
      const n = fn(zr(e)),
        { options: s } = qe(Ws),
        r = Ie(() => ({
          [Qr(e.activeClass, s.linkActiveClass, "router-link-active")]:
            n.isActive,
          [Qr(
            e.exactActiveClass,
            s.linkExactActiveClass,
            "router-link-exact-active",
          )]: n.isExactActive,
        }));
      return () => {
        const o = t.default && xu(t.default(n));
        return e.custom
          ? o
          : Us(
              "a",
              {
                "aria-current": n.isExactActive ? e.ariaCurrentValue : null,
                href: n.href,
                onClick: n.navigate,
                class: r.value,
              },
              o,
            );
      };
    },
  }),
  Cu = wu;
function Ru(e) {
  if (
    !(e.metaKey || e.altKey || e.ctrlKey || e.shiftKey) &&
    !e.defaultPrevented &&
    !(e.button !== void 0 && e.button !== 0)
  ) {
    if (e.currentTarget && e.currentTarget.getAttribute) {
      const t = e.currentTarget.getAttribute("target");
      if (/\b_blank\b/i.test(t)) return;
    }
    return (e.preventDefault && e.preventDefault(), !0);
  }
}
function Pu(e, t) {
  for (const n in t) {
    const s = t[n],
      r = e[n];
    if (typeof s == "string") {
      if (s !== r) return !1;
    } else if (!$e(r) || r.length !== s.length || s.some((o, i) => o !== r[i]))
      return !1;
  }
  return !0;
}
function Jr(e) {
  return e ? (e.aliasOf ? e.aliasOf.path : e.path) : "";
}
const Qr = (e, t, n) => e ?? t ?? n,
  Au = Ho({
    name: "RouterView",
    inheritAttrs: !1,
    props: { name: { type: String, default: "default" }, route: Object },
    compatConfig: { MODE: 3 },
    setup(e, { attrs: t, slots: n }) {
      const s = qe(xs),
        r = Ie(() => e.route || s.value),
        o = qe(Gr, 0),
        i = Ie(() => {
          let d = Nt(o);
          const { matched: f } = r.value;
          let a;
          for (; (a = f[d]) && !a.components;) d++;
          return d;
        }),
        l = Ie(() => r.value.matched[i.value]);
      (_n(
        Gr,
        Ie(() => i.value + 1),
      ),
        _n(Eu, l),
        _n(xs, r));
      const c = js();
      return (
        zt(
          () => [c.value, l.value, e.name],
          ([d, f, a], [p, m, E]) => {
            (f &&
              ((f.instances[a] = d),
              m &&
                m !== f &&
                d &&
                d === p &&
                (f.leaveGuards.size || (f.leaveGuards = m.leaveGuards),
                f.updateGuards.size || (f.updateGuards = m.updateGuards))),
              d &&
                f &&
                (!m || !$t(f, m) || !p) &&
                (f.enterCallbacks[a] || []).forEach((P) => P(d)));
          },
          { flush: "post" },
        ),
        () => {
          const d = r.value,
            f = e.name,
            a = l.value,
            p = a && a.components[f];
          if (!p) return Yr(n.default, { Component: p, route: d });
          const m = a.props[f],
            E = m
              ? m === !0
                ? d.params
                : typeof m == "function"
                  ? m(d)
                  : m
              : null,
            V = Us(
              p,
              Z({}, E, t, {
                onVnodeUnmounted: (F) => {
                  F.component.isUnmounted && (a.instances[f] = null);
                },
                ref: c,
              }),
            );
          return Yr(n.default, { Component: V, route: d }) || V;
        }
      );
    },
  });
function Yr(e, t) {
  if (!e) return null;
  const n = e(t);
  return n.length === 1 ? n[0] : n;
}
const Tu = Au;
function Ou(e) {
  const t = gu(e.routes, e),
    n = e.parseQuery || bu,
    s = e.stringifyQuery || qr,
    r = e.history,
    o = Bt(),
    i = Bt(),
    l = Bt(),
    c = pl(st);
  let d = st;
  It &&
    e.scrollBehavior &&
    "scrollRestoration" in history &&
    (history.scrollRestoration = "manual");
  const f = rs.bind(null, (y) => "" + y),
    a = rs.bind(null, kf),
    p = rs.bind(null, ln);
  function m(y, I) {
    let R, $;
    return (
      Oi(y) ? ((R = t.getRecordMatcher(y)), ($ = I)) : ($ = y),
      t.addRoute($, R)
    );
  }
  function E(y) {
    const I = t.getRecordMatcher(y);
    I && t.removeRoute(I);
  }
  function P() {
    return t.getRoutes().map((y) => y.record);
  }
  function V(y) {
    return !!t.getRecordMatcher(y);
  }
  function F(y, I) {
    if (((I = Z({}, I || c.value)), typeof y == "string")) {
      const g = os(n, y, I.path),
        v = t.resolve({ path: g.path }, I),
        b = r.createHref(g.fullPath);
      return Z(g, v, {
        params: p(v.params),
        hash: ln(g.hash),
        redirectedFrom: void 0,
        href: b,
      });
    }
    let R;
    if (y.path != null) R = Z({}, y, { path: os(n, y.path, I.path).path });
    else {
      const g = Z({}, y.params);
      for (const v in g) g[v] == null && delete g[v];
      ((R = Z({}, y, { params: a(g) })), (I.params = a(I.params)));
    }
    const $ = t.resolve(R, I),
      re = y.hash || "";
    $.params = f(p($.params));
    const u = Wf(s, Z({}, y, { hash: Hf(re), path: $.path })),
      h = r.createHref(u);
    return Z(
      { fullPath: u, hash: re, query: s === qr ? Su(y.query) : y.query || {} },
      $,
      { redirectedFrom: void 0, href: h },
    );
  }
  function L(y) {
    return typeof y == "string" ? os(n, y, c.value.path) : Z({}, y);
  }
  function N(y, I) {
    if (d !== y) return Dt(8, { from: I, to: y });
  }
  function M(y) {
    return G(y);
  }
  function B(y) {
    return M(Z(L(y), { replace: !0 }));
  }
  function ne(y) {
    const I = y.matched[y.matched.length - 1];
    if (I && I.redirect) {
      const { redirect: R } = I;
      let $ = typeof R == "function" ? R(y) : R;
      return (
        typeof $ == "string" &&
          (($ = $.includes("?") || $.includes("#") ? ($ = L($)) : { path: $ }),
          ($.params = {})),
        Z(
          {
            query: y.query,
            hash: y.hash,
            params: $.path != null ? {} : y.params,
          },
          $,
        )
      );
    }
  }
  function G(y, I) {
    const R = (d = F(y)),
      $ = c.value,
      re = y.state,
      u = y.force,
      h = y.replace === !0,
      g = ne(R);
    if (g)
      return G(
        Z(L(g), {
          state: typeof g == "object" ? Z({}, re, g.state) : re,
          force: u,
          replace: h,
        }),
        I || R,
      );
    const v = R;
    v.redirectedFrom = I;
    let b;
    return (
      !u && qf(s, $, R) && ((b = Dt(16, { to: v, from: $ })), De($, $, !0, !1)),
      (b ? Promise.resolve(b) : U(v, $))
        .catch((_) => (Qe(_) ? (Qe(_, 2) ? _ : tt(_)) : X(_, v, $)))
        .then((_) => {
          if (_) {
            if (Qe(_, 2))
              return G(
                Z({ replace: h }, L(_.to), {
                  state: typeof _.to == "object" ? Z({}, re, _.to.state) : re,
                  force: u,
                }),
                I || v,
              );
          } else _ = O(v, $, !0, h, re);
          return (Q(v, $, _), _);
        })
    );
  }
  function W(y, I) {
    const R = N(y, I);
    return R ? Promise.reject(R) : Promise.resolve();
  }
  function A(y) {
    const I = Rt.values().next().value;
    return I && typeof I.runWithContext == "function"
      ? I.runWithContext(y)
      : y();
  }
  function U(y, I) {
    let R;
    const [$, re, u] = Iu(y, I);
    R = is($.reverse(), "beforeRouteLeave", y, I);
    for (const g of $)
      g.leaveGuards.forEach((v) => {
        R.push(ct(v, y, I));
      });
    const h = W.bind(null, y, I);
    return (
      R.push(h),
      Te(R)
        .then(() => {
          R = [];
          for (const g of o.list()) R.push(ct(g, y, I));
          return (R.push(h), Te(R));
        })
        .then(() => {
          R = is(re, "beforeRouteUpdate", y, I);
          for (const g of re)
            g.updateGuards.forEach((v) => {
              R.push(ct(v, y, I));
            });
          return (R.push(h), Te(R));
        })
        .then(() => {
          R = [];
          for (const g of u)
            if (g.beforeEnter)
              if ($e(g.beforeEnter))
                for (const v of g.beforeEnter) R.push(ct(v, y, I));
              else R.push(ct(g.beforeEnter, y, I));
          return (R.push(h), Te(R));
        })
        .then(
          () => (
            y.matched.forEach((g) => (g.enterCallbacks = {})),
            (R = is(u, "beforeRouteEnter", y, I, A)),
            R.push(h),
            Te(R)
          ),
        )
        .then(() => {
          R = [];
          for (const g of i.list()) R.push(ct(g, y, I));
          return (R.push(h), Te(R));
        })
        .catch((g) => (Qe(g, 8) ? g : Promise.reject(g)))
    );
  }
  function Q(y, I, R) {
    l.list().forEach(($) => A(() => $(y, I, R)));
  }
  function O(y, I, R, $, re) {
    const u = N(y, I);
    if (u) return u;
    const h = I === st,
      g = It ? history.state : {};
    (R &&
      ($ || h
        ? r.replace(y.fullPath, Z({ scroll: h && g && g.scroll }, re))
        : r.push(y.fullPath, re)),
      (c.value = y),
      De(y, I, R, h),
      tt());
  }
  let z;
  function ae() {
    z ||
      (z = r.listen((y, I, R) => {
        if (!dn.listening) return;
        const $ = F(y),
          re = ne($);
        if (re) {
          G(Z(re, { replace: !0, force: !0 }), $).catch(Yt);
          return;
        }
        d = $;
        const u = c.value;
        (It && eu(Dr(u.fullPath, R.delta), Kn()),
          U($, u)
            .catch((h) =>
              Qe(h, 12)
                ? h
                : Qe(h, 2)
                  ? (G(Z(L(h.to), { force: !0 }), $)
                      .then((g) => {
                        Qe(g, 20) &&
                          !R.delta &&
                          R.type === cn.pop &&
                          r.go(-1, !1);
                      })
                      .catch(Yt),
                    Promise.reject())
                  : (R.delta && r.go(-R.delta, !1), X(h, $, u)),
            )
            .then((h) => {
              ((h = h || O($, u, !1)),
                h &&
                  (R.delta && !Qe(h, 8)
                    ? r.go(-R.delta, !1)
                    : R.type === cn.pop && Qe(h, 20) && r.go(-1, !1)),
                Q($, u, h));
            })
            .catch(Yt));
      }));
  }
  let me = Bt(),
    se = Bt(),
    q;
  function X(y, I, R) {
    tt(y);
    const $ = se.list();
    return (
      $.length ? $.forEach((re) => re(y, I, R)) : console.error(y),
      Promise.reject(y)
    );
  }
  function Ge() {
    return q && c.value !== st
      ? Promise.resolve()
      : new Promise((y, I) => {
          me.add([y, I]);
        });
  }
  function tt(y) {
    return (
      q ||
        ((q = !y),
        ae(),
        me.list().forEach(([I, R]) => (y ? R(y) : I())),
        me.reset()),
      y
    );
  }
  function De(y, I, R, $) {
    const { scrollBehavior: re } = e;
    if (!It || !re) return Promise.resolve();
    const u =
      (!R && tu(Dr(y.fullPath, 0))) ||
      (($ || !R) && history.state && history.state.scroll) ||
      null;
    return Hs()
      .then(() => re(y, I, u))
      .then((h) => h && Zf(h))
      .catch((h) => X(h, y, I));
  }
  const Se = (y) => r.go(y);
  let Ct;
  const Rt = new Set(),
    dn = {
      currentRoute: c,
      listening: !0,
      addRoute: m,
      removeRoute: E,
      clearRoutes: t.clearRoutes,
      hasRoute: V,
      getRoutes: P,
      resolve: F,
      options: e,
      push: M,
      replace: B,
      go: Se,
      back: () => Se(-1),
      forward: () => Se(1),
      beforeEach: o.add,
      beforeResolve: i.add,
      afterEach: l.add,
      onError: se.add,
      isReady: Ge,
      install(y) {
        const I = this;
        (y.component("RouterLink", Cu),
          y.component("RouterView", Tu),
          (y.config.globalProperties.$router = I),
          Object.defineProperty(y.config.globalProperties, "$route", {
            enumerable: !0,
            get: () => Nt(c),
          }),
          It &&
            !Ct &&
            c.value === st &&
            ((Ct = !0), M(r.location).catch((re) => {})));
        const R = {};
        for (const re in st)
          Object.defineProperty(R, re, {
            get: () => c.value[re],
            enumerable: !0,
          });
        (y.provide(Ws, I), y.provide(Ni, wo(R)), y.provide(xs, c));
        const $ = y.unmount;
        (Rt.add(y),
          (y.unmount = function () {
            (Rt.delete(y),
              Rt.size < 1 &&
                ((d = st),
                z && z(),
                (z = null),
                (c.value = st),
                (Ct = !1),
                (q = !1)),
              $());
          }));
      },
    };
  function Te(y) {
    return y.reduce((I, R) => I.then(() => A(R)), Promise.resolve());
  }
  return dn;
}
function Iu(e, t) {
  const n = [],
    s = [],
    r = [],
    o = Math.max(t.matched.length, e.matched.length);
  for (let i = 0; i < o; i++) {
    const l = t.matched[i];
    l && (e.matched.find((d) => $t(d, l)) ? s.push(l) : n.push(l));
    const c = e.matched[i];
    c && (t.matched.find((d) => $t(d, c)) || r.push(c));
  }
  return [n, s, r];
}
const Mu = Ou({
    history: ou("/"),
    routes: [
      {
        path: "/",
        name: "main",
        redirect: "store",
        component: () =>
          vn(() => import("./MainPage-DNgxZQEI.js"), __vite__mapDeps([0, 1])),
        children: [
          {
            path: "/about",
            name: "about",
            component: () => vn(() => import("./AboutPage-BqketiP2.js"), []),
          },
          {
            path: "/store",
            name: "store",
            component: () =>
              vn(
                () => import("./StorePage-B_V4ojS9.js"),
                __vite__mapDeps([2, 3]),
              ),
          },
          {
            path: "/servers",
            name: "servers",
            component: () => vn(() => import("./ServersPage-BbTcwV8q.js"), []),
          },
        ],
      },
    ],
  }),
  qs = hf(Rf),
  Lu = vf();
qs.use(Mu);
qs.use(Lu);
qs.mount("#app");
export {
  Ue as F,
  Hu as T,
  xf as _,
  hi as a,
  ko as b,
  $u as c,
  Ko as d,
  Fu as e,
  fn as f,
  Du as g,
  we as h,
  Ul as i,
  wc as j,
  ku as k,
  ju as l,
  Bu as m,
  Ts as n,
  fi as o,
  Nu as p,
  Hs as q,
  js as r,
  Gi as t,
  Vu as v,
  Pl as w,
};
